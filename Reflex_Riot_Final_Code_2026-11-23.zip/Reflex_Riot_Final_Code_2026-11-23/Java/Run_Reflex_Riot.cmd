@echo off
setlocal
cd /d "%~dp0"
where java.exe >nul 2>nul
if errorlevel 1 (
    echo Java 8 or newer is required. Install it or add Java to PATH.
    pause
    exit /b 1
)
java.exe -jar "%~dp0ReflexRiot.jar" %*
if errorlevel 1 pause
