param([string]$Port, [int]$Baud)
$ErrorActionPreference = 'Stop'
$bytes = New-Object byte[] 256
$inputStream = [Console]::OpenStandardInput()
$outputStream = [Console]::OpenStandardOutput()
$pending = $inputStream.ReadAsync($bytes, 0, $bytes.Length)
while (!$pending.IsCompleted) { Start-Sleep -Milliseconds 4 }
$size = $pending.GetAwaiter().GetResult()
$command = [Text.Encoding]::ASCII.GetString($bytes, 0, $size).Trim()
if ($command -ne 'CMD,17,PING') { throw "Unexpected command $command" }
$pending = $inputStream.ReadAsync($bytes, 0, $bytes.Length)
$payload = [Text.Encoding]::ASCII.GetBytes('ACK,17,OK')
[byte[]]$ack = @(165, 90, 1, 2, $payload.Length) + $payload + @(0, 0)
$crc = 65535
for ($i = 2; $i -lt $ack.Length - 2; $i++) {
    $crc = $crc -bxor ([int]$ack[$i] -shl 8)
    for ($bit = 0; $bit -lt 8; $bit++) {
        if ($crc -band 32768) { $crc = (($crc -shl 1) -bxor 4129) -band 65535 }
        else { $crc = ($crc -shl 1) -band 65535 }
    }
}
$ack[$ack.Length - 2] = $crc -shr 8
$ack[$ack.Length - 1] = $crc -band 255
# Reproduce the live USB reset: a VALID old status, then a cut/corrupt packet.
# Neither establishes synchronization with this new connection.
[byte[]]$oldPayload = [Text.Encoding]::ASCII.GetBytes('STATUS,DISTANCE_MM,1867,TOO_FAR,148524')
[byte[]]$oldFrame = @(165,90,1,2,$oldPayload.Length) + $oldPayload + @(0,0)
$oldCrc = 65535
for ($i=2; $i -lt $oldFrame.Length-2; $i++) {
    $oldCrc = $oldCrc -bxor ([int]$oldFrame[$i] -shl 8)
    for ($bit=0; $bit -lt 8; $bit++) {
        if ($oldCrc -band 32768) {$oldCrc=(($oldCrc -shl 1) -bxor 4129) -band 65535}
        else {$oldCrc=($oldCrc -shl 1) -band 65535}
    }
}
$oldFrame[$oldFrame.Length-2]=$oldCrc -shr 8
$oldFrame[$oldFrame.Length-1]=$oldCrc -band 255
$outputStream.Write($oldFrame,0,$oldFrame.Length)
# A bad startup frame must still be discarded after that valid old status.
[byte[]]$bad = $ack.Clone()
$bad[5] = $bad[5] -bxor 1
$outputStream.Write($bad, 0, $bad.Length)
$outputStream.Write($ack, 0, $ack.Length)
$outputStream.Flush()
# After synchronization the same corruption must fail the connection.
Start-Sleep -Milliseconds 200
$outputStream.Write($bad, 0, $bad.Length)
$outputStream.Flush()
Start-Sleep -Milliseconds 2000
