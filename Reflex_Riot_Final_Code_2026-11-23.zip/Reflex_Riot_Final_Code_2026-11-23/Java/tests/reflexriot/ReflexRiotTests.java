package reflexriot;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.swing.SwingUtilities;

public final class ReflexRiotTests {
    private static final long SECOND = 1_000_000_000L;
    private static int assertions;

    public static void main(String[] args) throws Exception {
        patternContracts();
        gameRules();
        sevenActionSequence();
        weightedTwistSelection();
        leaderboard();
        stationProtocol();
        controllerIntegration();
        audioFiles();
        if (args.length > 0 && "--windows".equals(args[0])) windowsBridge();
        System.out.println("PASS " + assertions + " assertions");
    }

    private static void check(boolean condition, String message) {
        assertions++;
        if (!condition) throw new AssertionError(message);
    }

    private static long begin(GameSession game, long readyAt) {
        game.ready(readyAt);
        check(game.state() == GameSession.State.ARMING, "Ready requests station preparation");
        game.tick(readyAt + SECOND);
        check(game.state() == GameSession.State.ARMING, "No countdown before station acknowledgment");
        game.beginCountdown(readyAt);
        check(game.state() == GameSession.State.COUNTDOWN, "Acknowledgment starts countdown");
        check(game.countdown(readyAt) == 3 && game.countdown(readyAt + SECOND) == 2, "3-2 countdown");
        game.tick(readyAt + 3 * SECOND - 1);
        check(game.state() == GameSession.State.COUNTDOWN, "Countdown lasts three seconds");
        long go = readyAt + 3 * SECOND;
        game.tick(go);
        check(game.state() == GameSession.State.PLAYING, "Timer starts immediately at countdown end");
        check(game.remaining(go + 1_000_000L) == game.allowanceNanos() - 1_000_000L,
                "Clock decreases immediately without a GO playback wait");
        return go;
    }

    private static void patternContracts() {
        GameSession subject = new GameSession(new Random(5));
        int[] calls = {0, 0};
        GameSession.Listener persistent = signal -> calls[0]++;
        GameSession.Listener[] once = new GameSession.Listener[1];
        once[0] = signal -> { calls[1]++; subject.removeListener(once[0]); };
        subject.addListener(persistent);
        subject.addListener(persistent);
        subject.addListener(once[0]);
        subject.start(GameSession.Mode.SOLO);
        check(calls[0] == 1 && calls[1] == 1, "Observer registration is unique and self-removal is safe");
        subject.menu();
        check(calls[0] == 2 && calls[1] == 1, "Removed observer receives no further signals");
        subject.removeListener(persistent);
        subject.start(GameSession.Mode.SOLO);
        check(calls[0] == 2, "Observer contract supports explicit removal");

        Clock clock = new Clock();
        List<SensorEvent> events = new ArrayList<>();
        StationClient context = new StationClient(new StationClient.Listener() {
            public void onStationChanged() {}
            public void onSensor(SensorEvent event) { events.add(event); }
            public void onStationFault(String detail) { throw new AssertionError(detail); }
        }, () -> clock.now);
        Wire first = new Wire(clock), replacement = new Wire(clock);
        try {
            context.open(first); first.handshake();
            context.open(replacement);
            check(first.closed && !replacement.closed, "Strategy replacement closes the old gateway");
            replacement.handshake();
            first.line("EVT,1,READY,0,1");
            check(events.isEmpty(), "Old strategy callbacks cannot enter the new session");
            replacement.line("EVT,1,READY,0,1");
            check(events.size() == 1 && context.ready(), "Replacement strategy uses the same game-facing contract");
        } finally { context.close(); }
        check(replacement.closed, "Strategy context closes the active implementation");
    }

    private static void gameRules() {
        EnumSet<ActionType> firstMoves = EnumSet.noneOf(ActionType.class);
        Random random = new Random(301);
        for (int i = 0; i < 100; i++) {
            GameSession trial = new GameSession(random);
            trial.start(GameSession.Mode.SOLO);
            firstMoves.add(trial.latest());
        }
        check(firstMoves.equals(EnumSet.of(ActionType.TWIST, ActionType.CLAP, ActionType.HAND_CLOSE,
                ActionType.DIAL_CLOCKWISE, ActionType.DIAL_COUNTERCLOCKWISE,
                ActionType.RFID_SCAN, ActionType.COVER_LIGHT)), "Exactly the seven enabled moves in Round 1");
        GameSession game = new GameSession(new Random(42));
        List<GameSession.Signal> signals = new ArrayList<>();
        game.addListener(signals::add);
        game.start(GameSession.Mode.SOLO);
        game.tick(100 * SECOND);
        game.input(game.latest(), 100 * SECOND);
        check(game.progress() == 0 && game.state() == GameSession.State.PREVIEW, "Unlimited preparation");
        long now = 100 * SECOND;
        long summedAllowance = 0;
        long summedScore = 0;
        List<ActionType> moves = new ArrayList<>();
        for (int round = 1; round <= 14; round++) {
            check(game.round() == round, "Exactly one action appended per round");
            check(moves.isEmpty() || game.latest() != moves.get(moves.size() - 1), "No adjacent duplicates");
            moves.add(game.latest());
            summedAllowance += game.latest().seconds * SECOND;
            long go = begin(game, now);
            check(game.remaining(go) == summedAllowance, "Round allowance adds all action times");
            game.input(moves.get(0), go - 1);
            check(game.progress() == 0, "Pre-GO events are ignored");
            for (int i = 0; i < moves.size(); i++) {
                game.input(moves.get(i), go + (i + 1) * SECOND);
                check(game.progress() == i + 1, "One progress update per correct move");
                if (i + 1 < moves.size()) {
                    check(game.remaining(go + (i + 1) * SECOND) == summedAllowance - (i + 1) * SECOND,
                            "Correct action does not reset timer");
                }
            }
            summedScore += round * 1000L;
            check(game.completedRounds() == round && game.completedMillis() == summedScore,
                    "Scoring includes completed active rounds only");
            now = go + (round + 1) * SECOND;
            game.roundFeedbackFinished();
        }
        long go = begin(game, now);
        game.input(moves.get(0), go + game.allowanceNanos());
        check(game.state() == GameSession.State.GAME_OVER && game.result().equals("Time expired."),
                "A move at the exact deadline loses");
        check(game.completedMillis() == summedScore && game.completedRounds() == 14, "Timeout adds no score");
        check(signals.contains(GameSession.Signal.CORRECT) && signals.contains(GameSession.Signal.ROUND_PASSED),
                "Observers receive correct-move and round signals");

        game.start(GameSession.Mode.VERSUS);
        check(game.playerLabel().equals("Player 1"), "First 1v1 starts with Player 1");
        ActionType first = game.latest();
        go = begin(game, now);
        game.input(first, go + SECOND);
        game.roundFeedbackFinished();
        check(game.playerLabel().equals("Player 2") && game.round() == 2, "Players share the growing sequence");
        go = begin(game, go + 2 * SECOND);
        game.input(game.latest(), go + SECOND); // New move differs from the earlier first move.
        check(game.state() == GameSession.State.GAME_OVER && game.result().contains("Player 1 wins"),
                "One wrong move eliminates the active player");
        game.start(GameSession.Mode.VERSUS);
        check(game.playerLabel().equals("Player 2"), "Next 1v1 alternates starting player");
        go = begin(game, now);
        game.tick(go + game.allowanceNanos());
        check(game.result().contains("Player 1 wins"), "Versus timeout awards the other player");
        game.start(GameSession.Mode.VERSUS);
        game.interrupt("Station lost");
        check(game.state() == GameSession.State.INTERRUPTED && !game.result().contains("wins"),
                "A hardware fault is not a gameplay loss");
    }

    private static void sevenActionSequence() {
        // Always choosing index zero must still skip the previous enabled action.
        for (GameSession.Mode mode : GameSession.Mode.values()) {
            Random lowest = new Random(1) {
                private static final long serialVersionUID = 1L;
                @Override public int nextInt(int bound) { return 0; }
            };
            GameSession game = new GameSession(lowest, new Random(2));
            game.start(mode);
            List<ActionType> sequence = new ArrayList<>();
            long now = 0;
            for (int round = 1; round <= 20; round++) {
                ActionType move = game.latest();
                check(Arrays.asList(ActionType.MOVES).contains(move), "Removed gestures never enter a sequence");
                check(sequence.isEmpty() || move != sequence.get(sequence.size() - 1),
                        "Filtered action pool still prevents consecutive repeats");
                sequence.add(move);
                long go = begin(game, now);
                for (int i = 0; i < sequence.size(); i++)
                    game.input(sequence.get(i), go + (i + 1) * 1_000_000L);
                check(game.completedRounds() == round, "Filtered sequence completes in solo and versus");
                game.roundFeedbackFinished();
                now = go + SECOND;
            }
        }
    }

    private static void weightedTwistSelection() {
        // Exhaust every ticket: exact weights, rather than a flaky frequency test.
        for (GameSession.Mode mode : GameSession.Mode.values()) {
            java.util.EnumMap<ActionType, Integer> firstCounts = new java.util.EnumMap<>(ActionType.class);
            for (int ticket = 0; ticket < 8; ticket++) {
                final int chosenTicket = ticket;
                Random fixed = new Random(1) {
                    private static final long serialVersionUID = 1L;
                    @Override public int nextInt(int bound) { return chosenTicket; }
                };
                GameSession game = new GameSession(fixed, new Random(2));
                game.start(mode);
                firstCounts.put(game.latest(), firstCounts.getOrDefault(game.latest(), 0) + 1);
            }
            for (ActionType action : ActionType.MOVES)
                check(firstCounts.get(action) == (action == ActionType.TWIST ? 2 : 1),
                        "Round 1 keeps all seven moves, with two tickets for Twist");
            int[] firstTickets = {0, 2, 3, 4, 5, 6, 7};
            for (int previous = 0; previous < ActionType.MOVES.length; previous++) {
                final int initialTicket = firstTickets[previous];
                ActionType previousMove = ActionType.MOVES[previous];
                java.util.EnumMap<ActionType, Integer> nextCounts = new java.util.EnumMap<>(ActionType.class);
                int choices = previousMove == ActionType.TWIST ? 6 : 7;
                for (int ticket = 0; ticket < choices; ticket++) {
                    final int chosenTicket = ticket;
                    Random fixed = new Random(1) {
                        private static final long serialVersionUID = 1L;
                        private int calls;
                        @Override public int nextInt(int bound) {
                            int result = calls++ == 0 ? initialTicket : chosenTicket;
                            if (result >= bound) throw new AssertionError("Ticket outside random bound");
                            return result;
                        }
                    };
                    GameSession game = new GameSession(fixed, new Random(2));
                    game.start(mode);
                    check(game.latest() == previousMove, "Test starts with the intended previous action");
                    long go = begin(game, 0);
                    game.input(previousMove, go + SECOND);
                    game.roundFeedbackFinished();
                    ActionType selected = game.latest();
                    check(selected != previousMove, "Weighting cannot produce consecutive duplicates");
                    nextCounts.put(selected, nextCounts.getOrDefault(selected, 0) + 1);
                }
                for (ActionType action : ActionType.MOVES) {
                    int expected = action == previousMove ? 0 : action == ActionType.TWIST ? 2 : 1;
                    check(nextCounts.getOrDefault(action, 0) == expected,
                            "Later-round weights remain correct after every possible previous move");
                }
            }
        }
    }

    private static void leaderboard() throws Exception {
        Path folder = Files.createTempDirectory("reflex-riot-test-");
        Path file = folder.resolve("scores.tsv");
        try {
            LeaderboardService ranks = new LeaderboardService(file);
            ranks.load();
            check(!ranks.qualifies(0, 0), "No score for an unfinished first round");
            check(ranks.add("Amina", 2, 8000), "Save first result");
            ranks.add("Bader", 3, 9500);
            ranks.add("Dana", 3, 8700);
            ranks.add("Omar", 4, 12000);
            ranks.add("Lina", 1, 2800);
            check(ranks.add("Hana", 2, 7500), "A higher round displaces the fifth score");
            check(!ranks.add("Karim", 2, 9000), "A slower tie does not displace fifth");
            try {
                ranks.add("bad\tname", 8, 10000);
                throw new AssertionError("Name validation did not run");
            } catch (IllegalArgumentException expected) {
                check(true, "Invalid display names are rejected");
            }
            Files.write(file, "damaged row\n".getBytes(StandardCharsets.UTF_8),
                    java.nio.file.StandardOpenOption.APPEND);
            LeaderboardService reopened = new LeaderboardService(file);
            reopened.load();
            check(reopened.scores().size() == 5, "The top five persist after reopen");
            List<String> names = new ArrayList<>();
            for (LeaderboardService.Score score : reopened.scores()) names.add(score.name);
            check(names.equals(Arrays.asList("Omar", "Dana", "Bader", "Hana", "Amina")),
                    "Round count and completed-round time determine ranking");
        } finally {
            Files.deleteIfExists(file);
            Files.deleteIfExists(folder);
        }
    }

    private static final class Clock {
        long now = SECOND;
        void step(long millis) { now += TimeUnit.MILLISECONDS.toNanos(millis); }
    }

    private static final class Wire implements SensorGateway {
        final List<String> sent = new ArrayList<>();
        final Clock clock;
        Listener listener;
        boolean closed;

        Wire(Clock clock) { this.clock = clock; }
        @Override public void start(Listener value) { listener = value; }
        @Override public void send(String line) { sent.add(line); }
        @Override public void close() { closed = true; }
        String last() { return sent.get(sent.size() - 1); }
        String id() { return last().split(",")[1]; }
        void line(String frame) { listener.onLine(frame, clock.now); }
        void ack() { line("ACK," + id() + ",OK"); }
        void handshake() {
            check(last().endsWith(",INPUT_DISARM"), "Handshake disarms the station");
            ack();
            check(last().endsWith(",STATUS"), "Handshake requests STATUS");
            line("STATUS,STATE,DISARMED,CAL,1,MPU,1,FAULT,0,EPOCH,0");
            ack();
            line("STATUS,DISTANCE_MM,650,IN_RANGE,0");
        }
    }

    private static void stationProtocol() {
        Clock clock = new Clock();
        Wire wire = new Wire(clock);
        List<SensorEvent> events = new ArrayList<>();
        List<String> faults = new ArrayList<>();
        StationClient station = new StationClient(new StationClient.Listener() {
            @Override public void onStationChanged() {}
            @Override public void onSensor(SensorEvent event) { events.add(event); }
            @Override public void onStationFault(String message) { faults.add(message); }
        }, () -> clock.now);
        station.open(wire);
        wire.handshake();
        check(station.ready() && station.distanceFresh(clock.now), "Station synced and calibrated");
        wire.line("EVT,4294967295,READY,0,1");
        wire.line("EVT,1,RFID_SCAN,3,2,012345ABCD");
        wire.line("EVT,1,RFID_SCAN,3,2,012345ABCD");
        wire.line("EVT,4294967295,READY,0,1");
        check(events.size() == 2 && events.get(1).epoch == 3, "Sequence wrap and duplicate filtering");
        wire.line("EVT,3,TWIST,3,4");
        check(events.size() == 2 && faults.size() == 1, "Sequence gap aborts instead of judging a move");
        wire.line("EVT,4,RFID_SCAN,3,4,INVALID");
        check(faults.size() == 2, "Malformed RFID events cannot reach the game");
        List<String> ack = new ArrayList<>();
        station.arm(3, () -> ack.add("arm"), faults::add);
        String original = wire.last();
        clock.step(650);
        station.tick(clock.now);
        check(wire.last().equals(original), "Retry reuses the original command ID and payload");
        wire.ack();
        wire.ack();
        check(ack.size() == 1, "Duplicate ACK does not start a second turn");
        station.muteForCue(() -> ack.add("cue"));
        clock.step(650);
        station.tick(clock.now);
        wire.ack();
        check(ack.size() == 1, "A replayed mute ACK cannot play a late cue");
        station.muteForCue(() -> ack.add("cue"));
        clock.step(40);
        wire.ack();
        check(ack.size() == 2, "A timely mute ACK permits the cue");
        clock.step(1000);
        station.tick(clock.now);
        check(wire.last().endsWith(",PING"), "Heartbeat stays off the gameplay clock");
        for (int i = 0; i < 4; i++) {
            clock.step(650);
            station.tick(clock.now);
        }
        check(!station.connected() && wire.closed, "Link timeout closes the stale session");
    }

    private static void controllerIntegration() {
        Clock clock = new Clock();
        Wire wire = new Wire(clock);
        GameSession session = new GameSession(new Random(17));
        AudioManager audio = new AudioManager();
        audio.setMuted(true);
        GameController controller = new GameController(session,
                new LeaderboardService(Paths.get("unused-test-score-file")), audio, () -> clock.now,
                Paths.get("serial-bridge.ps1"));
        try {
            controller.station().open(wire);
            wire.handshake();
            controller.start(GameSession.Mode.SOLO);
            wire.ack(); // LED_BLUE.
            wire.line("STATUS,DISTANCE_MM,-1,UNKNOWN,0");
            wire.line("EVT,2,READY,0,20");
            check(session.state() == GameSession.State.ARMING && wire.last().contains(",INPUT_ARM,"),
                    "Ready pre-arms the station even without an echo");
            long epoch = Long.parseLong(wire.last().split(",")[3]);
            wire.ack();
            check(session.state() == GameSession.State.COUNTDOWN, "ARM ACK starts the countdown");
            wire.line("EVT,3," + session.latest() + "," + epoch + ",25"
                    + (session.latest() == ActionType.RFID_SCAN ? ",012345ABCD" : ""));
            check(session.progress() == 0, "Early armed events cannot score during countdown");
            clock.step(2999);
            controller.tick();
            if (wire.last().endsWith(",PING")) wire.ack();
            check(session.state() == GameSession.State.COUNTDOWN, "No gameplay before three seconds");
            clock.step(1);
            controller.tick();
            check(session.state() == GameSession.State.PLAYING && controller.goAt() == clock.now,
                    "GO starts immediately even with audio muted");
            clock.step(500);
            wire.line("EVT,4,CLAP," + (epoch - 1) + ",30");
            check(session.progress() == 0, "Stale-turn event is ignored");
            ActionType next = session.latest();
            String tag = next == ActionType.RFID_SCAN ? ",012345ABCD" : "";
            wire.line("EVT,5," + next + "," + epoch + ",40" + tag);
            check(session.state() == GameSession.State.ROUND_PASSED && session.completedMillis() == 500,
                    "Firmware action completes the round and scores active time");
            check(wire.last().endsWith(",INPUT_DISARM"), "Completed round disarms the station");
            wire.ack();
            check(wire.last().endsWith(",LED_GREEN"), "Completed action triggers green feedback");
            wire.ack();
            clock.step(950);
            controller.tick();
            check(session.state() == GameSession.State.PREVIEW && session.round() == 2, "Next preview is automatic");
            wire.ack(); // LED_BLUE.
            wire.line("STATUS,DISTANCE_MM,1600,TOO_FAR,0");
            wire.line("EVT,6,READY,0,50");
            check(session.state() == GameSession.State.ARMING, "Ready prepares the station even when far away");
            epoch = Long.parseLong(wire.last().split(",")[3]);
            wire.ack();
            clock.step(3000);
            controller.tick();
            if (wire.last().endsWith(",PING")) wire.ack();
            wire.line("EVT,7," + (next == ActionType.CLAP ? "TWIST" : "CLAP") + "," + epoch + ",60");
            check(session.state() == GameSession.State.GAME_OVER && wire.last().endsWith(",FEEDBACK_WRONG"),
                    "A wrong move ends immediately and asks the Mega to vibrate");
        } finally {
            controller.close();
        }
    }

    private static void audioFiles() throws Exception {
        List<String> assets = new ArrayList<>(Arrays.asList("correct", "countdown", "go"));
        for (int i = 1; i <= 8; i++) assets.add("early_" + i);
        for (int i = 1; i <= 4; i++) {
            assets.add("wrong_" + i);
            assets.add("timeout_" + i);
        }
        for (String name : assets) {
            try (InputStream raw = AudioManager.class.getResourceAsStream("/audio/" + name + ".wav")) {
                check(raw != null, "Sound packaged: " + name);
                try (AudioInputStream wav = AudioSystem.getAudioInputStream(new BufferedInputStream(raw))) {
                    check(wav.getFrameLength() > 0, "Sound decodes: " + name);
                    float duration = wav.getFrameLength() / wav.getFormat().getFrameRate();
                    if ("go".equals(name)) check(Math.abs(duration - 0.350f) < 0.001f, "GO beep duration");
                    if ("correct".equals(name)) check(duration > 1.5f && duration < 1.6f, "Approved correct cue");
                }
            }
        }
    }

    private static void windowsBridge() throws Exception {
        CountDownLatch received = new CountDownLatch(1);
        CountDownLatch failed = new CountDownLatch(1);
        AtomicReference<String> answer = new AtomicReference<>();
        AtomicReference<String> error = new AtomicReference<>();
        AtomicReference<String> startupError = new AtomicReference<>();
        WindowsSerialGateway link = new WindowsSerialGateway("COM9999", 115200, Paths.get("tests/pipe-test.ps1"));
        SwingUtilities.invokeAndWait(() -> {
            link.start(new SensorGateway.Listener() {
                @Override public void onLine(String line, long at) {
                    if ("ACK,17,OK".equals(line)) {
                        answer.set(line);
                        received.countDown();
                    }
                }
                @Override public void onFailure(String detail) {
                    error.set(detail);
                    if (answer.get() == null) {
                        startupError.set(detail);
                        received.countDown();
                    }
                    failed.countDown();
                }
            });
            link.send("CMD,17,PING");
        });
        try {
            check(received.await(8, TimeUnit.SECONDS), "Child process pipes respond after startup noise");
            check(startupError.get() == null, "Reset leftovers do not fail the connection before its fresh ACK");
            check("ACK,17,OK".equals(answer.get()), "Old valid status and damaged reset packet do not establish synchronization");
            check(failed.await(3, TimeUnit.SECONDS), "Corruption after synchronization interrupts the connection");
            check(error.get().contains("checksum"), "Checksum protection remains strict after synchronization");
        } finally {
            link.close();
        }
    }
}
