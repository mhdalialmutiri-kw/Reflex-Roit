package reflexriot;

import java.nio.file.Paths;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** Optional COM check. Runs the normal startup handshake and leaves inputs disarmed. */
public final class LiveStationCheck {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) throw new IllegalArgumentException("Supply the Mega COM port.");
        CountDownLatch result = new CountDownLatch(1);
        AtomicReference<String> outcome = new AtomicReference<>("The station did not finish connecting.");
        StationClient[] link = new StationClient[1];
        Timer timer = new Timer(25, event -> link[0].tick(System.nanoTime()));
        SwingUtilities.invokeAndWait(() -> {
            link[0] = new StationClient(new StationClient.Listener() {
                @Override public void onStationChanged() {
                    if (link[0].ready()) {
                        outcome.set("PASS live USB handshake and calibrated station");
                        result.countDown();
                    }
                }
                @Override public void onSensor(SensorEvent event) {}
                @Override public void onStationFault(String detail) {
                    outcome.set(detail);
                    result.countDown();
                }
            }, System::nanoTime);
            link[0].open(new WindowsSerialGateway(args[0].toUpperCase(Locale.ROOT), 115200,
                    Paths.get("serial-bridge.ps1")));
            timer.start();
        });
        try {
            result.await(8, TimeUnit.SECONDS);
            if (!outcome.get().startsWith("PASS")) throw new AssertionError(outcome.get());
            System.out.println(outcome.get());
        } finally {
            SwingUtilities.invokeAndWait(() -> {
                timer.stop();
                link[0].close();
            });
        }
    }
}
