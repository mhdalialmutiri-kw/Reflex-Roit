package reflexriot;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class BinaryProtocolTest {
    private static int checks;
    public static void main(String[] args) throws Exception {
        List<String> messages = new ArrayList<>();
        int[] failures = {0};
        BinaryProtocol reader = new BinaryProtocol(messages::add, () -> failures[0]++);
        byte[] headerNoise = {0, (byte)165, 1, 90};
        for (byte b : headerNoise) reader.accept(b & 255);
        byte[] first = null;
        int accepted = 0;
        for (int id = 1; id <= 11; ++id) {
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            DataOutputStream data = new DataOutputStream(bytes);
            data.writeByte(id);
            data.writeInt(-1);
            data.writeInt(0xA55A0000); // Header bytes are permitted inside a payload.
            data.writeInt(0);
            if (id == 9) data.writeBytes("012345ABCD");
            byte[] packet = frame(1, bytes.toByteArray());
            if (id == 3) first = packet;
            for (byte b : packet) reader.accept(b & 255);
            if (id == 1 || id == 2 || id == 4) {
                require(messages.size() == accepted, "Reserved motion IDs cannot become game actions");
                continue;
            }
            accepted++;
            require(messages.size() == accepted, "All enabled action IDs decode byte by byte");
            require(messages.get(accepted - 1).startsWith("EVT,4294967295,"), "Unsigned sequence preserved");
        }
        require(failures[0] == 3, "All three reserved IDs are rejected");
        byte[] bad = first.clone();
        bad[6] ^= 1;
        for (byte b : bad) reader.accept(b & 255);
        require(messages.size() == 8 && failures[0] > 3, "Corrupt event discarded");
        byte[] ack = frame(2, "ACK,17,OK".getBytes(StandardCharsets.US_ASCII));
        for (byte b : ack) reader.accept(b & 255);
        require(messages.get(messages.size() - 1).equals("ACK,17,OK"), "Resynchronizes after a corrupt packet");
        int before = messages.size();
        for (byte b : frame(1, new byte[12])) reader.accept(b & 255);
        require(messages.size() == before, "Invalid action length rejected");
        for (int split = 0; split < first.length; split++) {
            List<String> output = new ArrayList<>();
            BinaryProtocol partial = new BinaryProtocol(output::add, () -> {});
            for (int n = 0; n < split; n++) partial.accept(first[n] & 255);
            require(output.isEmpty(), "Waits for a complete packet");
            for (int n = split; n < first.length; n++) partial.accept(first[n] & 255);
            require(output.size() == 1, "Partial packet resumes");
        }
        if (args.length == 1) {
            List<String> output = new ArrayList<>();
            BinaryProtocol firmware = new BinaryProtocol(output::add, () -> {
                throw new AssertionError("Firmware packet failed validation");
            });
            for (byte b : Files.readAllBytes(Paths.get(args[0]))) firmware.accept(b & 255);
            require(output.equals(Arrays.asList("EVT,4294967295,TWIST,2774138880,0")),
                    "Actual C++ encoder bytes decode in Java");
        }
        System.out.println("PASS " + checks + " binary protocol checks");
    }

    private static byte[] frame(int type, byte[] payload) {
        byte[] packet = new byte[payload.length + 7];
        packet[0] = (byte)165; packet[1] = 90; packet[2] = 1;
        packet[3] = (byte)type; packet[4] = (byte)payload.length;
        System.arraycopy(payload, 0, packet, 5, payload.length);
        int crc = BinaryProtocol.crc(packet, 2, payload.length + 3);
        packet[packet.length - 2] = (byte)(crc >> 8);
        packet[packet.length - 1] = (byte)crc;
        return packet;
    }
    private static void require(boolean value, String detail) {
        checks++;
        if (!value) throw new AssertionError(detail);
    }
}
