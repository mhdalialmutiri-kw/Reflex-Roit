package reflexriot;

import java.util.Random;

/** Checks game rules without a screen, audio device, or Arduino. */
public final class GameTimingTest {
    private static final long SECOND = 1_000_000_000L;
    private static int checks;

    public static void main(String[] args) {
        for (int seed = 0; seed < 32; seed++) verifyMatch(seed);
        System.out.println("PASS " + checks + " timing and feedback checks");
    }

    private static void verifyMatch(int seed) {
        GameSession game = new GameSession(new Random(seed), new Random(seed + 100));
        game.start(GameSession.Mode.SOLO);
        ActionType[] sequence = new ActionType[5];
        int taunts = 0;
        long allowance = 0;
        long readyAt = 10 * SECOND;
        for (int round = 1; round <= sequence.length; round++) {
            require(game.round() == round, "One new action each round");
            sequence[round - 1] = game.latest();
            require(round == 1 || sequence[round - 1] != sequence[round - 2], "No adjacent repeats");
            allowance += game.latest().seconds * SECOND;
            game.ready(readyAt);
            require(game.state() == GameSession.State.ARMING, "Station prepares before countdown");
            game.beginCountdown(readyAt);
            for (int second = 0; second < 3; second++) {
                long time = readyAt + second * SECOND;
                game.tick(time);
                require(game.countdown(time) == 3 - second, "Show 3, 2 and 1");
            }
            long goDisplayedAt = readyAt + 3 * SECOND;
            game.tick(goDisplayedAt);
            require(game.state() == GameSession.State.PLAYING, "Timer runs at 3-2-1-GO boundary");
            long playedAt = goDisplayedAt;
            require(game.remaining(playedAt) == allowance, "Timer starts with the full round allowance");
            for (int move = 0; move < round; move++) {
                game.input(sequence[move], playedAt + (move + 1) * SECOND);
                require(game.progress() == move + 1, "A correct action advances progress");
                if (move + 1 < round) {
                    require(game.remaining(playedAt + (move + 1) * SECOND)
                            == allowance - (move + 1) * SECOND, "The timer keeps running");
                }
            }
            require(game.state() == GameSession.State.ROUND_PASSED, "Correct sequence completes the round");
            if (game.tauntAfterRound()) {
                require(round <= 4, "Taunts only occur in rounds 1–4");
                require(game.tauntClip().matches("early_[1-8]"), "Taunt uses one of eight clips");
                taunts++;
            }
            readyAt = playedAt + 20 * SECOND;
            game.tick(readyAt);
            require(game.state() == GameSession.State.ROUND_PASSED, "Round screen waits for feedback");
            game.roundFeedbackFinished();
        }
        require(taunts == 1, "One early taunt per match that reaches round 4");
        require(game.completedRounds() == 5 && game.completedMillis() == 15_000,
                "Score uses active time for completed rounds only");
        require(game.lossClip(GameSession.Signal.WRONG).matches("wrong_[1-4]"), "Wrong-move clip pool");
        require(game.lossClip(GameSession.Signal.TIMEOUT).matches("timeout_[1-4]"), "Timeout clip pool");
    }

    private static void require(boolean condition, String description) {
        if (!condition) throw new AssertionError(description);
        checks++;
    }
}
