package reflexriot;

import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.nio.file.Paths;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

/** Exercises the Swing controls and the developer simulator without a station. */
public final class GuiSmoke {
    public static void main(String[] args) throws Exception {
        GameSession game = new GameSession(new Random(4));
        AudioManager audio = new AudioManager();
        audio.setMuted(true);
        GameController controller = new GameController(game,
                new LeaderboardService(Paths.get("unused-smoke-score-file")), audio,
                System::nanoTime, Paths.get("serial-bridge.ps1"));
        GameView[] window = new GameView[1];
        Timer timer = new Timer(25, event -> controller.tick());
        SwingUtilities.invokeAndWait(() -> {
            window[0] = new GameView(controller, true);
            controller.attach(window[0]);
            controller.simulate();
            timer.start();
        });
        try {
            SwingUtilities.invokeAndWait(() -> {});
            SwingUtilities.invokeAndWait(() -> {
                click(window[0], "Start Solo");
                expect(game.state() == GameSession.State.PREVIEW, "Solo starts from the button");
                click(window[0], "Ready");
                expect(game.state() == GameSession.State.COUNTDOWN, "Simulated Ready starts countdown");
            });
            Thread.sleep(3600);
            SwingUtilities.invokeAndWait(() -> {
                expect(game.state() == GameSession.State.PLAYING, "Countdown and simulated ARM ACK reach GO");
                if (args.length > 0) render(window[0], args[0]);
                controller.simulatedAction(game.latest());
                expect(game.state() == GameSession.State.ROUND_PASSED, "Simulated action completes the round");
            });
            Thread.sleep(1050);
            SwingUtilities.invokeAndWait(() -> {
                expect(game.state() == GameSession.State.PREVIEW && game.round() == 2, "Second round appears");
                click(window[0], "Main menu");
                click(window[0], "Start 1v1");
                expect(game.mode() == GameSession.Mode.VERSUS, "1v1 starts from the button");
            });
            System.out.println("PASS Swing and simulated station smoke test");
        } finally {
            SwingUtilities.invokeAndWait(() -> {
                timer.stop();
                controller.close();
                window[0].dispose();
            });
        }
    }

    private static void render(GameView view, String file) {
        JComponent panel = (JComponent) view.getContentPane();
        view.validate();
        BufferedImage image = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_RGB);
        Graphics2D graphics = image.createGraphics();
        panel.printAll(graphics);
        graphics.dispose();
        try {
            ImageIO.write(image, "png", Paths.get(file).toFile());
        } catch (java.io.IOException e) {
            throw new AssertionError(e);
        }
    }

    private static void click(Container root, String label) {
        JButton button = find(root, label);
        expect(button != null && button.isEnabled(), "Enabled button " + label);
        button.doClick(0);
    }

    private static JButton find(Container root, String label) {
        for (Component component : root.getComponents()) {
            if (component instanceof JButton && label.equals(((JButton) component).getText())) {
                return (JButton) component;
            }
            if (component instanceof Container) {
                JButton nested = find((Container) component, label);
                if (nested != null) return nested;
            }
        }
        return null;
    }

    private static void expect(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
