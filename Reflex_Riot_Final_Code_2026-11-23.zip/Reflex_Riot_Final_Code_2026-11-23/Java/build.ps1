param(
    [string]$JdkBin,
    [switch]$RunTests
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$classes = Join-Path $root 'build/classes'
New-Item -ItemType Directory -Path $classes -Force | Out-Null
if (-not $JdkBin -and $env:JAVA_HOME) { $JdkBin = Join-Path $env:JAVA_HOME 'bin' }
$javac = if ($JdkBin) { Join-Path $JdkBin 'javac.exe' } else { 'javac.exe' }
$java = if ($JdkBin) { Join-Path $JdkBin 'java.exe' } else { 'java.exe' }
$version = (& $javac -version) | Out-String
$compatibility = if ($version -match 'javac 1\.8\.') {
    @('-source', '8', '-target', '8')
} else {
    @('--release', '8', '-Xlint:-options')
}
$sources = @(Get-ChildItem (Join-Path $root 'src') -Recurse -Filter '*.java' |
        ForEach-Object FullName)
& $javac @compatibility -Xlint:all,-options -Werror -encoding UTF-8 -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed.' }

# Eclipse launches bin/, while the command-line build uses build/classes/.
# Keep both outputs current so Eclipse cannot silently launch an earlier game.
$eclipseClasses = Join-Path $root 'bin'
foreach ($class in (Get-ChildItem $classes -Recurse -Filter '*.class')) {
    $relative = $class.FullName.Substring($classes.Length + 1)
    $destination = Join-Path $eclipseClasses $relative
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null
    Copy-Item -LiteralPath $class.FullName -Destination $destination -Force
}

# A JAR is a ZIP with a Java manifest. Keep the build usable when javac is present
# but the optional jar.exe packaging tool is absent.
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$jar = Join-Path $root 'ReflexRiot.jar'
$stream = [IO.File]::Create($jar)
try {
    $archive = [IO.Compression.ZipArchive]::new($stream, [IO.Compression.ZipArchiveMode]::Create, $true)
    try {
        $manifest = $archive.CreateEntry('META-INF/MANIFEST.MF').Open()
        try {
            $data = [Text.Encoding]::ASCII.GetBytes("Manifest-Version: 1.0`r`nMain-Class: reflexriot.Main`r`n`r`n")
            $manifest.Write($data, 0, $data.Length)
        } finally {
            $manifest.Dispose()
        }
        foreach ($class in (Get-ChildItem $classes -Recurse -Filter '*.class')) {
            $entry = $class.FullName.Substring($classes.Length + 1).Replace('\', '/')
            [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $class.FullName, $entry)
        }
        foreach ($sound in (Get-ChildItem (Join-Path $root 'audio') -Filter '*.wav')) {
            [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $sound.FullName, "audio/$($sound.Name)")
        }
    } finally {
        $archive.Dispose()
    }
} finally {
    $stream.Dispose()
}
Write-Host "Built $jar"

if ($RunTests) {
    $testClasses = Join-Path $root 'build/tests'
    New-Item -ItemType Directory -Path $testClasses -Force | Out-Null
    $tests = @(Get-ChildItem (Join-Path $root 'tests') -Recurse -Filter '*.java' | ForEach-Object FullName)
    & $javac @compatibility -Xlint:all,-options -Werror -encoding UTF-8 -cp $jar -d $testClasses @tests
    if ($LASTEXITCODE -ne 0) { throw 'Java test compilation failed.' }
    Push-Location $root
    try {
        & $java -cp "$jar;$testClasses" reflexriot.ReflexRiotTests --windows
        if ($LASTEXITCODE -ne 0) { throw 'Java tests failed.' }
        & $java -cp "$jar;$testClasses" reflexriot.GameTimingTest
        if ($LASTEXITCODE -ne 0) { throw 'Game timing tests failed.' }
        & $java -cp "$jar;$testClasses" reflexriot.BinaryProtocolTest
        if ($LASTEXITCODE -ne 0) { throw 'Binary protocol tests failed.' }
    } finally {
        Pop-Location
    }
}
