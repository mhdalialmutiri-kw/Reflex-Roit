package reflexriot;

final class SensorEvent {
    static final long UINT_MAX = 0xffff_ffffL;
    final long sequence;
    final ActionType action;
    final long epoch;
    final long receivedAt;

    private SensorEvent(long sequence, ActionType action, long epoch, long receivedAt) {
        this.sequence = sequence;
        this.action = action;
        this.epoch = epoch;
        this.receivedAt = receivedAt;
    }

    static SensorEvent parse(String[] fields, long receivedAt) {
        if (fields.length < 5) throw new IllegalArgumentException("Incomplete action frame");
        long seq = unsigned(fields[1]);
        ActionType action = ActionType.valueOf(fields[2]);
        boolean rfid = action == ActionType.RFID_SCAN;
        if (seq == 0 || fields.length != (rfid ? 6 : 5)
                || (rfid && !fields[5].matches("[0-9A-F]{10}"))) {
            throw new IllegalArgumentException("Invalid action frame");
        }
        unsigned(fields[4]); // Validate Mega uptime without using it as the Java clock.
        return new SensorEvent(seq, action, unsigned(fields[3]), receivedAt);
    }

    static long unsigned(String value) {
        if (!value.matches("[0-9]{1,10}")) throw new IllegalArgumentException("Invalid number");
        long number = Long.parseLong(value);
        if (number > UINT_MAX) throw new IllegalArgumentException("Number exceeds 32 bits");
        return number;
    }
}
