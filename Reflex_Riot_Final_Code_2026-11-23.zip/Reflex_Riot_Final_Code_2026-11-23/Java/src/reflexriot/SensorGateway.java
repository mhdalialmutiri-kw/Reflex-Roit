package reflexriot;

/** Strategy contract for station communication. Real and simulated strategies
 * deliver callbacks on Swing's event thread, keeping game rules independent. */
interface SensorGateway extends AutoCloseable {
    interface Listener {
        void onLine(String line, long receivedAt);
        void onFailure(String detail);
    }

    void start(Listener listener);
    void send(String command);
    @Override void close();
}
