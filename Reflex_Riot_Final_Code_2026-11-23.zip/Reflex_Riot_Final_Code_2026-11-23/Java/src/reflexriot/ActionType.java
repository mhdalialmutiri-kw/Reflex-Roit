package reflexriot;

/** Seven gameplay actions; Twist is the only handheld motion challenge. */
enum ActionType {
    TWIST("Twist the controller", "Hold D40, twist your wrist, then release. Release between twists.", 5),
    CLAP("Clap", "Clap once near the microphone.", 4),
    HAND_CLOSE("Move your hand close", "Bring your hand toward the front sensor.", 4),
    DIAL_CLOCKWISE("Turn the dial clockwise", "Turn the dial one click clockwise.", 4),
    DIAL_COUNTERCLOCKWISE("Turn the dial counterclockwise", "Turn the dial one click counterclockwise.", 4),
    RFID_SCAN("Scan an RFID tag", "Present the tag to the reader, then remove it.", 6),
    COVER_LIGHT("Cover the light sensor", "Cover the light sensor, then uncover it.", 4),
    READY("Ready", "", 0);

    static final ActionType[] MOVES = {
        TWIST, CLAP, HAND_CLOSE, DIAL_CLOCKWISE, DIAL_COUNTERCLOCKWISE, RFID_SCAN, COVER_LIGHT
    };
    final String label;
    final String instruction;
    final int seconds;

    ActionType(String label, String instruction, int seconds) {
        this.label = label;
        this.instruction = instruction;
        this.seconds = seconds;
    }
}
