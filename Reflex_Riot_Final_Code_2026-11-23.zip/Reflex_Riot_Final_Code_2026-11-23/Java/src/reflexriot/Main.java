package reflexriot;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Random;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public final class Main {
    private Main() {}

    public static void main(String[] args) {
        Path root = applicationDirectory();
        String appData = System.getenv("LOCALAPPDATA");
        Path data = Paths.get(appData == null ? System.getProperty("user.home") : appData, "ReflexRiot");
        LeaderboardService leaderboard = new LeaderboardService(data.resolve("leaderboard.tsv"));
        String loadMessage = "";
        try {
            leaderboard.load();
        } catch (IOException e) {
            loadMessage = "Could not read scores: " + e.getMessage();
        }
        final String initialNotice = loadMessage;
        boolean simulator = args.length == 1 && "--simulate".equals(args[0]);
        SwingUtilities.invokeLater(() -> {
            GameController controller = new GameController(new GameSession(new Random()),
                    leaderboard, new AudioManager(root.resolve("audio")), System::nanoTime,
                    root.resolve("serial-bridge.ps1"));
            controller.storageNotice(initialNotice);
            GameView view = new GameView(controller, simulator);
            controller.attach(view);
            Timer clock = new Timer(25, event -> controller.tick());
            view.addWindowListener(new WindowAdapter() {
                @Override public void windowClosed(WindowEvent event) {
                    clock.stop();
                    controller.close();
                }
            });
            view.refresh();
            view.setVisible(true);
            clock.start();
            if (simulator) controller.simulate();
        });
    }

    private static Path applicationDirectory() {
        try {
            Path location = Paths.get(Main.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            if (Files.isRegularFile(location)) return location.toAbsolutePath().getParent();
            for (Path folder = location.toAbsolutePath(); folder != null; folder = folder.getParent()) {
                if (Files.isRegularFile(folder.resolve("serial-bridge.ps1"))) return folder;
            }
        } catch (URISyntaxException | IllegalArgumentException ignored) {
            // An IDE can run unpacked classes with the project directory as its working directory.
        }
        return Paths.get("").toAbsolutePath();
    }
}
