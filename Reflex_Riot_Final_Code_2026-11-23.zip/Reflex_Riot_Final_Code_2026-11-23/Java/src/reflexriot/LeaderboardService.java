package reflexriot;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

final class LeaderboardService {
    static final class Score {
        final String name;
        final int rounds;
        final long milliseconds;

        Score(String name, int rounds, long milliseconds) {
            this.name = name;
            this.rounds = rounds;
            this.milliseconds = milliseconds;
        }
    }

    private static final int LIMIT = 5;
    private static final Comparator<Score> RANK = Comparator
            .comparingInt((Score score) -> score.rounds).reversed()
            .thenComparingLong(score -> score.milliseconds);
    private final Path file;
    private List<Score> scores = new ArrayList<>();

    LeaderboardService(Path file) {
        this.file = file.toAbsolutePath();
    }

    void load() throws IOException {
        List<Score> loaded = new ArrayList<>();
        if (Files.notExists(file)) return;
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split("\t", -1);
                if (fields.length != 3 || !validName(fields[0])) continue;
                try {
                    int rounds = Integer.parseInt(fields[1]);
                    long time = Long.parseLong(fields[2]);
                    if (rounds > 0 && time >= 0) loaded.add(new Score(fields[0], rounds, time));
                } catch (NumberFormatException ignored) {
                    // A damaged row should not erase other scores.
                }
            }
        }
        scores = topFive(loaded);
    }

    List<Score> scores() { return Collections.unmodifiableList(scores); }

    boolean qualifies(int rounds, long time) {
        return rounds > 0 && time >= 0 && (scores.size() < LIMIT
                || RANK.compare(new Score("", rounds, time), scores.get(LIMIT - 1)) < 0);
    }

    boolean add(String name, int rounds, long time) throws IOException {
        name = name.trim();
        if (!validName(name)) throw new IllegalArgumentException("Use 1–24 letters, digits, spaces, _ or -.");
        if (!qualifies(rounds, time)) return false;
        List<Score> next = new ArrayList<>(scores);
        next.add(new Score(name, rounds, time));
        next = topFive(next);
        Files.createDirectories(file.getParent());
        Path temp = Files.createTempFile(file.getParent(), "reflex-riot-", ".tmp");
        try {
            try (BufferedWriter writer = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) {
                for (Score score : next) {
                    writer.write(score.name + "\t" + score.rounds + "\t" + score.milliseconds);
                    writer.newLine();
                }
            }
            try {
                Files.move(temp, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(temp, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temp);
        }
        scores = next;
        return true;
    }

    private static List<Score> topFive(List<Score> entries) {
        entries.sort(RANK);
        return new ArrayList<>(entries.subList(0, Math.min(LIMIT, entries.size())));
    }

    private static boolean validName(String name) {
        return name.matches("[\\p{L}\\p{N} _-]{1,24}") && !name.trim().isEmpty();
    }
}
