package reflexriot;

import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.SwingUtilities;

/** Starts the Windows port bridge. Pipe reads and writes run off the UI thread. */
final class WindowsSerialGateway implements SensorGateway {
    private final String port;
    private final int baud;
    private final Path script;
    private final BlockingQueue<String> output = new ArrayBlockingQueue<>(24);
    private final AtomicBoolean closed = new AtomicBoolean();
    private final AtomicBoolean failurePosted = new AtomicBoolean();
    private final AtomicReference<String> bridgeError = new AtomicReference<>();
    private volatile Process process;
    private volatile Thread writer;
    private Listener listener;
    private boolean handshakeConfirmed; // Reader thread only.
    private final AtomicReference<String> expectedAck = new AtomicReference<>();

    WindowsSerialGateway(String port, int baud, Path script) {
        if (!port.matches("COM[1-9][0-9]{0,3}")) throw new IllegalArgumentException("Enter a COM port such as COM17.");
        this.port = port;
        this.baud = baud;
        this.script = script.toAbsolutePath();
    }

    @Override public void start(Listener listener) {
        this.listener = listener;
        worker("station-reader", this::connectAndRead);
    }

    @Override public void send(String line) {
        if (!closed.get() && !output.offer(line)) fail("The station write queue filled.");
    }

    private void connectAndRead() {
        try {
            if (!Files.isRegularFile(script)) throw new IOException("serial-bridge.ps1 is missing beside the app.");
            Process started = new ProcessBuilder("powershell.exe", "-NoLogo", "-NoProfile",
                    "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script.toString(),
                    "-Port", port, "-Baud", Integer.toString(baud)).start();
            process = started;
            if (closed.get()) {
                started.destroy();
                return;
            }
            Thread errors = worker("station-errors", () -> readErrors(started));
            writer = worker("station-writer", () -> writeCommands(started));
            if (closed.get()) writer.interrupt();
            BinaryProtocol decoder = new BinaryProtocol(frame -> {
                    // Complete old packets can precede a partial packet during USB reset.
                    // Only a reply to a command from THIS connection establishes sync.
                    if (frame.startsWith("BOOT,REFLEX_RIOT,")) {
                        handshakeConfirmed = false;
                        expectedAck.set(null);
                    } else if (frame.equals(expectedAck.get())) {
                        handshakeConfirmed = true;
                    }
                    long received = System.nanoTime();
                    SwingUtilities.invokeLater(() -> {
                        if (!closed.get()) listener.onLine(frame, received);
                    });
                }, () -> {
                    // Ignore reset leftovers until a fresh command receives its valid ACK.
                    // After that, keep rejecting corrupt data rather than inventing moves.
                    if (handshakeConfirmed) fail("A station packet failed its checksum. Reconnect before playing.");
                });
            try (BufferedInputStream reader = new BufferedInputStream(started.getInputStream())) {
                int value;
                while (!closed.get() && (value = reader.read()) != -1) {
                    decoder.accept(value);
                }
            }
            started.waitFor(200, TimeUnit.MILLISECONDS);
            errors.join(150);
            String detail = bridgeError.get();
            fail(detail == null ? port + " disconnected." : port + ": " + detail);
        } catch (IOException e) {
            fail(port + ": " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private void readErrors(Process started) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(started.getErrorStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) bridgeError.set(line.trim());
            }
        } catch (IOException ignored) {
            // The process or station may already have been closed.
        }
    }

    private void writeCommands(Process started) {
        try (BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
                started.getOutputStream(), StandardCharsets.US_ASCII))) {
            while (!closed.get()) {
                String command = output.take();
                String[] fields = command.split(",", 4);
                if (fields.length >= 3 && "CMD".equals(fields[0])) {
                    expectedAck.set("ACK," + fields[1] + ",OK");
                }
                out.write(command);
                out.write('\n');
                out.flush();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (IOException e) {
            if (started.isAlive()) fail("Could not send to " + port + ": " + e.getMessage());
        }
    }

    private static Thread worker(String name, Runnable action) {
        Thread thread = new Thread(action, name);
        thread.setDaemon(true);
        thread.start();
        return thread;
    }

    private void fail(String detail) {
        if (closed.get() || !failurePosted.compareAndSet(false, true)) return;
        SwingUtilities.invokeLater(() -> {
            if (!closed.get()) listener.onFailure(detail);
        });
    }

    @Override public void close() {
        closed.set(true);
        Thread sending = writer;
        if (sending != null) sending.interrupt();
        Process running = process;
        if (running != null) running.destroy();
    }
}
