package reflexriot;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.function.Consumer;

/** Incremental Mega packet reader. Delivers validated events to the existing game interface. */
final class BinaryProtocol {
    private static final int MAX_PAYLOAD = 98;
    // Explicit wire IDs preserve the installed Mega protocol. IDs 1, 2 and 4 are reserved.
    private static final String[] ACTIONS = {
        null, null, null, "TWIST", null, "CLAP", "HAND_CLOSE",
        "DIAL_CLOCKWISE", "DIAL_COUNTERCLOCKWISE", "RFID_SCAN", "COVER_LIGHT", "READY"
    };
    private final byte[] buffer = new byte[MAX_PAYLOAD + 7];
    private final Consumer<String> receiver;
    private final Runnable corrupt;
    private int size;

    BinaryProtocol(Consumer<String> receiver, Runnable corrupt) {
        this.receiver = receiver;
        this.corrupt = corrupt;
    }

    void accept(int value) {
        buffer[size++] = (byte) value;
        while (size > 0) {
            if ((buffer[0] & 255) != 0xA5 || (size >= 2 && (buffer[1] & 255) != 0x5A)) {
                discard(1);
                continue;
            }
            if (size < 5) return;
            int length = buffer[4] & 255;
            if (buffer[2] != 1 || length > MAX_PAYLOAD ||
                    (buffer[3] != 1 && buffer[3] != 2)) {
                corrupt.run();
                discard(1);
                continue;
            }
            int total = length + 7;
            if (size < total) return;
            int checksum = crc(buffer, 2, 3 + length);
            int transmitted = ((buffer[total - 2] & 255) << 8) | (buffer[total - 1] & 255);
            if (checksum != transmitted) {
                corrupt.run();
                discard(1);
                continue;
            }
            byte[] payload = Arrays.copyOfRange(buffer, 5, 5 + length);
            int type = buffer[3];
            discard(total);
            try {
                receiver.accept(type == 1 ? event(payload) : message(payload));
            } catch (IllegalArgumentException e) {
                corrupt.run();
            }
        }
    }

    private void discard(int count) {
        System.arraycopy(buffer, count, buffer, 0, size - count);
        size -= count;
    }

    private static String event(byte[] data) {
        if (data.length != 13 && data.length != 23)
            throw new IllegalArgumentException("Invalid event size");
        int id = data[0] & 255;
        if (id == 0 || id >= ACTIONS.length || ACTIONS[id] == null || (id == 9) != (data.length == 23))
            throw new IllegalArgumentException("Invalid action");
        String line = "EVT," + unsigned32(data, 1) + "," + ACTIONS[id] + ","
                + unsigned32(data, 5) + "," + unsigned32(data, 9);
        if (id == 9) {
            String tag = new String(data, 13, 10, StandardCharsets.US_ASCII);
            if (!tag.matches("[0-9A-F]{10}")) throw new IllegalArgumentException("Invalid tag");
            line += "," + tag;
        }
        return line;
    }

    private static String message(byte[] payload) {
        for (byte value : payload) {
            if (value < 32 || value > 126) throw new IllegalArgumentException("Invalid status text");
        }
        return new String(payload, StandardCharsets.US_ASCII);
    }

    private static long unsigned32(byte[] data, int offset) {
        long result = 0;
        for (int i = 0; i < 4; ++i) result = (result << 8) | (data[offset + i] & 255);
        return result;
    }

    static int crc(byte[] data, int offset, int length) {
        int crc = 0xFFFF;
        for (int i = offset; i < offset + length; ++i) {
            crc ^= (data[i] & 255) << 8;
            for (int bit = 0; bit < 8; ++bit) {
                crc = ((crc & 0x8000) != 0 ? (crc << 1) ^ 0x1021 : crc << 1) & 0xFFFF;
            }
        }
        return crc;
    }
}
