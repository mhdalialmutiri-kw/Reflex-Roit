package reflexriot;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/** Swing owns the display and controls. Earlier sequence entries never reach this view. */
@SuppressWarnings("serial")
final class GameView extends JFrame implements GameSession.Listener {
    private static final long serialVersionUID = 1L;
    private static final Color BACKGROUND = new Color(15, 21, 32);
    private static final Color PANEL = new Color(27, 38, 54);
    private static final Color TEXT = new Color(240, 247, 255);
    private static final Color SECONDARY = new Color(176, 194, 213);
    private static final Color MINT = new Color(103, 241, 195);
    private static final Color ORANGE = new Color(255, 183, 103);
    private static final Color RED = new Color(255, 148, 139);
    private final GameController controller;
    private final GameSession game;
    private final JTextField port = new JTextField(6);
    private final JComboBox<String> transport = new JComboBox<>(new String[]{"USB", "XBee"});
    private final JButton connect = button("Connect", false);
    private final JButton calibrate = button("Calibrate", false);
    private final JButton solo = button("Start Solo", true);
    private final JButton versus = button("Start 1v1", false);
    private final JLabel station = label("", 13, false, SECONDARY);
    private final JLabel range = label("", 13, false, SECONDARY);
    private final JLabel notice = label(" ", 14, false, ORANGE);
    private final JPanel cards = new JPanel(new CardLayout());
    private final JLabel round = label("", 17, true, MINT);
    private final JLabel move = label("", 31, true, TEXT);
    private final JLabel instruction = label("", 16, false, SECONDARY);
    private final JLabel phase = label("", 37, true, ORANGE);
    private final JLabel progress = label("", 18, true, TEXT);
    private final JLabel time = label("", 23, true, TEXT);
    private final JProgressBar timeBar = new JProgressBar(0, 1000);
    private final JPanel timeStrip = new JPanel(new BorderLayout(10, 0));
    private final JPanel saveScore = new JPanel();
    private final JTextField name = new JTextField(14);
    private final JLabel storage = label(" ", 13, false, SECONDARY);
    private final JLabel[] scores = new JLabel[5];
    private final JLabel[] scoreStats = new JLabel[5];
    private final JPanel simulation = new JPanel(new BorderLayout(6, 6));

    GameView(GameController controller, boolean allowSimulator) {
        super("Reflex Riot - 7 moves");
        this.controller = controller;
        game = controller.game();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setMinimumSize(new Dimension(920, 600));
        setPreferredSize(new Dimension(1040, allowSimulator ? 755 : 650));
        JPanel root = new JPanel(new BorderLayout(16, 14));
        root.setBackground(BACKGROUND);
        root.setBorder(BorderFactory.createEmptyBorder(18, 22, 18, 22));
        setContentPane(root);
        root.add(header(), BorderLayout.NORTH);
        cards.setOpaque(false);
        cards.add(home(allowSimulator), "home");
        cards.add(gamePanel(), "game");
        root.add(cards, BorderLayout.CENTER);
        root.add(leaderboard(), BorderLayout.EAST);
        JPanel bottom = new JPanel(new BorderLayout(4, 6));
        bottom.setOpaque(false);
        bottom.add(notice, BorderLayout.NORTH);
        bottom.add(simulationPanel(), BorderLayout.CENTER);
        root.add(bottom, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null);
    }

    private JPanel header() {
        JPanel header = new JPanel(new BorderLayout(14, 7));
        header.setOpaque(false);
        header.add(label("REFLEX RIOT", 34, true, MINT), BorderLayout.WEST);
        JPanel controls = new JPanel();
        controls.setOpaque(false);
        port.setToolTipText("COM port from Arduino IDE or Device Manager");
        port.setText("COM17");
        connect.addActionListener(event -> {
            if (controller.station().connected()) controller.disconnect();
            else controller.connect(port.getText(), transport.getSelectedIndex() == 1);
        });
        calibrate.addActionListener(event -> controller.calibrate());
        JCheckBox mute = new JCheckBox("Mute");
        mute.setOpaque(false);
        mute.setForeground(TEXT);
        mute.addActionListener(event -> controller.mute(mute.isSelected()));
        JCheckBox headphones = new JCheckBox("Headphones");
        headphones.setOpaque(false);
        headphones.setForeground(TEXT);
        headphones.setToolTipText("Enable only if the station microphone cannot hear game audio.");
        headphones.addActionListener(event -> controller.headphoneAudio(headphones.isSelected()));
        controls.add(transport);
        controls.add(port);
        controls.add(connect);
        controls.add(calibrate);
        controls.add(mute);
        controls.add(headphones);
        header.add(controls, BorderLayout.EAST);
        JPanel state = new JPanel(new BorderLayout());
        state.setOpaque(false);
        state.add(station, BorderLayout.WEST);
        state.add(range, BorderLayout.EAST);
        header.add(state, BorderLayout.SOUTH);
        return header;
    }

    private JPanel home(boolean allowSimulator) {
        JPanel panel = card();
        panel.add(Box.createVerticalGlue());
        panel.add(label("Choose a game", 31, true, TEXT));
        panel.add(Box.createVerticalStrut(17));
        solo.addActionListener(event -> controller.start(GameSession.Mode.SOLO));
        versus.addActionListener(event -> controller.start(GameSession.Mode.VERSUS));
        panel.add(solo);
        panel.add(Box.createVerticalStrut(6));
        panel.add(label("Beat your best and climb the leaderboard.", 15, false, SECONDARY));
        panel.add(Box.createVerticalStrut(15));
        panel.add(versus);
        panel.add(Box.createVerticalStrut(6));
        panel.add(label("Take turns at one station. First mistake loses.", 15, false, SECONDARY));
        if (allowSimulator) {
            JButton reconnect = button("Connect simulator", false);
            reconnect.addActionListener(event -> controller.simulate());
            panel.add(Box.createVerticalStrut(18));
            panel.add(reconnect);
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private JPanel gamePanel() {
        JPanel panel = card();
        panel.add(round);
        panel.add(Box.createVerticalStrut(15));
        panel.add(move);
        panel.add(Box.createVerticalStrut(5));
        panel.add(instruction);
        panel.add(Box.createVerticalGlue());
        panel.add(phase);
        panel.add(Box.createVerticalStrut(8));
        panel.add(progress);
        panel.add(Box.createVerticalStrut(9));
        timeStrip.setOpaque(false);
        timeStrip.setAlignmentX(Component.LEFT_ALIGNMENT);
        timeStrip.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        timeBar.setForeground(MINT);
        timeBar.setBackground(BACKGROUND);
        timeBar.setBorderPainted(false);
        timeStrip.add(timeBar, BorderLayout.CENTER);
        timeStrip.add(time, BorderLayout.EAST);
        panel.add(timeStrip);
        panel.add(Box.createVerticalGlue());
        saveScore.setOpaque(false);
        saveScore.setAlignmentX(Component.LEFT_ALIGNMENT);
        saveScore.setLayout(new BoxLayout(saveScore, BoxLayout.X_AXIS));
        JLabel nameLabel = label("Leaderboard name", 13, false, TEXT);
        nameLabel.setLabelFor(name);
        name.setMaximumSize(new Dimension(190, 28));
        JButton save = button("Save score", true);
        save.addActionListener(event -> controller.save(name.getText()));
        name.addActionListener(event -> controller.save(name.getText()));
        saveScore.add(nameLabel);
        saveScore.add(Box.createHorizontalStrut(10));
        saveScore.add(name);
        saveScore.add(Box.createHorizontalStrut(8));
        saveScore.add(save);
        panel.add(saveScore);
        panel.add(storage);
        panel.add(Box.createVerticalStrut(8));
        JButton back = button("Main menu", false);
        back.addActionListener(event -> controller.menu());
        panel.add(back);
        return panel;
    }

    private JPanel leaderboard() {
        JPanel panel = card();
        panel.setPreferredSize(new Dimension(300, 380));
        panel.add(label("Solo leaderboard", 22, true, TEXT));
        panel.add(Box.createVerticalStrut(6));
        panel.add(label("Round  /  completed-round time", 13, false, SECONDARY));
        panel.add(Box.createVerticalStrut(15));
        for (int i = 0; i < scores.length; i++) {
            scores[i] = label("", 14, true, i == 0 ? MINT : TEXT);
            scoreStats[i] = label("", 13, false, SECONDARY);
            JPanel row = new JPanel(new BorderLayout(8, 0));
            row.setOpaque(false);
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));
            row.add(scores[i], BorderLayout.CENTER);
            row.add(scoreStats[i], BorderLayout.EAST);
            panel.add(row);
            panel.add(Box.createVerticalStrut(16));
        }
        panel.add(Box.createVerticalGlue());
        return panel;
    }

    private JPanel simulationPanel() {
        simulation.setOpaque(false);
        JLabel tag = label("Simulated station", 13, true, ORANGE);
        simulation.add(tag, BorderLayout.WEST);
        JPanel buttons = new JPanel(new GridLayout(2, 4, 5, 5));
        buttons.setOpaque(false);
        ActionType[] available = Arrays.copyOf(ActionType.MOVES, ActionType.MOVES.length + 1);
        available[available.length - 1] = ActionType.READY;
        for (ActionType action : available) {
            JButton button = button(action.label, false);
            button.setFont(new Font("Inter", Font.PLAIN, 11));
            button.setToolTipText(action.label);
            button.addActionListener(event -> controller.simulatedAction(action));
            buttons.add(button);
        }
        simulation.add(buttons, BorderLayout.CENTER);
        simulation.setVisible(false);
        return simulation;
    }

    @Override public void onGameSignal(GameSession.Signal signal) {
        if (signal == GameSession.Signal.PREVIEW) name.setText("");
        refresh();
    }

    void refresh() {
        StationClient link = controller.station();
        boolean home = game.state() == GameSession.State.MENU;
        ((CardLayout) cards.getLayout()).show(cards, home ? "home" : "game");
        station.setText(link.status());
        station.setForeground(link.ready() ? MINT : SECONDARY);
        range.setText(link.millimeters() < 0 ? "" : String.format(Locale.ROOT,
                "Sensor distance %.0f cm", link.millimeters() / 10.0));
        connect.setText(link.connected() ? "Disconnect" : "Connect");
        connect.setEnabled(!game.inMatch());
        port.setEnabled(!link.connected() && !game.inMatch());
        transport.setEnabled(!link.connected() && !game.inMatch());
        calibrate.setEnabled(link.connected() && !game.inMatch());
        solo.setEnabled(link.ready());
        versus.setEnabled(link.ready());
        simulation.setVisible(controller.simulated());
        String message = controller.notice();
        if (game.state() == GameSession.State.PREVIEW) message = controller.readyInstruction();
        else if (home && message.isEmpty()) message = controller.storageNotice();
        notice.setText(message.isEmpty() ? " " : message);
        updateScores();
        if (home) return;
        round.setText("Round " + game.round() + "    /    " + game.playerLabel());
        ActionType latest = game.latest();
        move.setText(latest == null ? "" : latest.label);
        instruction.setText(latest == null ? "" : latest.instruction);
        progress.setText(game.progress() + " / " + game.round() + " moves");
        saveScore.setVisible(controller.canSave());
        storage.setText(controller.storageNotice().isEmpty() ? " " : controller.storageNotice());
        phase.setForeground(ORANGE);
        switch (game.state()) {
            case PREVIEW:
                phase.setText("Get ready");
                break;
            case COUNTDOWN:
                phase.setText(Integer.toString(game.countdown(System.nanoTime())));
                break;
            case ARMING:
                phase.setText("Preparing station...");
                break;
            case START_CUE:
                phase.setText("GO");
                break;
            case PLAYING:
                phase.setForeground(MINT);
                phase.setText("GO");
                break;
            case ROUND_PASSED:
                phase.setForeground(MINT);
                phase.setText("Round complete");
                break;
            case GAME_OVER:
            case INTERRUPTED:
                phase.setFont(new Font("Inter", Font.BOLD, 28));
                phase.setForeground(RED);
                phase.setText(game.state() == GameSession.State.INTERRUPTED ? "Match interrupted" : "Game over");
                instruction.setText(game.result());
                progress.setText("Completed rounds: " + game.completedRounds());
                break;
            default:
                break;
        }
        if (game.inMatch()) phase.setFont(new Font("Inter", Font.BOLD, 37));
        timeStrip.setVisible(game.inMatch());
        updateClock(System.nanoTime());
    }

    void updateClock(long now) {
        if (game.state() == GameSession.State.COUNTDOWN) {
            phase.setText(Integer.toString(game.countdown(now)));
        } else if (game.state() == GameSession.State.PLAYING && phase.getText().equals("GO")
                && now - controller.goAt() >= TimeUnit.MILLISECONDS.toNanos(600)) {
            phase.setText("Your move");
        }
        if (game.inMatch()) {
            long remaining = game.state() == GameSession.State.ROUND_PASSED ? 0 : game.remaining(now);
            time.setText(String.format(Locale.ROOT, "%.1f s", remaining / 1_000_000_000.0));
            timeBar.setValue((int) (remaining * 1000.0 / Math.max(1, game.allowanceNanos())));
        }
    }

    private void updateScores() {
        List<LeaderboardService.Score> rows = controller.leaderboard().scores();
        for (int i = 0; i < scores.length; i++) {
            if (i < rows.size()) {
                LeaderboardService.Score row = rows.get(i);
                scores[i].setText((i + 1) + ". " + row.name);
                scoreStats[i].setText(String.format(Locale.ROOT, "R%d  ·  %.1fs",
                        row.rounds, row.milliseconds / 1000.0));
                scores[i].setToolTipText(row.name);
            } else {
                scores[i].setText(i == 0 ? "No scores yet" : " ");
                scoreStats[i].setText("");
                scores[i].setToolTipText(null);
            }
        }
    }

    private static JPanel card() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(PANEL);
        panel.setBorder(BorderFactory.createEmptyBorder(22, 23, 22, 23));
        return panel;
    }

    private static JLabel label(String text, int size, boolean bold, Color color) {
        JLabel label = new JLabel(text, SwingConstants.LEFT);
        label.setFont(new Font("Inter", bold ? Font.BOLD : Font.PLAIN, size));
        label.setForeground(color);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        return label;
    }

    private static JButton button(String text, boolean primary) {
        JButton button = new JButton(text);
        button.setFont(new Font("Inter", Font.BOLD, 13));
        button.setForeground(primary ? BACKGROUND : TEXT);
        button.setBackground(primary ? MINT : new Color(45, 61, 80));
        button.setOpaque(true);
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? MINT : new Color(91, 108, 128)),
                BorderFactory.createEmptyBorder(7, 12, 7, 12)));
        return button;
    }
}
