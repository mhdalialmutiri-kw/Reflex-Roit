package reflexriot;

import javax.swing.SwingUtilities;

/** Developer-only stand-in for the station. Uses the same lines as the hardware. */
final class SimulatedGateway implements SensorGateway {
    private Listener listener;
    private boolean closed;
    private long sequence;
    private long epoch;

    @Override public void start(Listener listener) { this.listener = listener; }

    @Override public void send(String command) {
        SwingUtilities.invokeLater(() -> {
            if (closed) return;
            String[] fields = command.split(",");
            switch (fields[2]) {
                case "STATUS":
                    emit("STATUS,STATE,DISARMED,CAL,1,MPU,1,FAULT,0,EPOCH,0");
                    break;
                case "INPUT_ARM":
                    epoch = Long.parseLong(fields[3]);
                    break;
                case "INPUT_DISARM":
                case "FEEDBACK_WRONG":
                    epoch = 0;
                    break;
                case "CALIBRATE":
                    emit("STATUS,CALIBRATED,LIGHT,600,MIC_THRESHOLD,18");
                    break;
                default:
                    break;
            }
            emit("ACK," + fields[1] + ",OK");
            emit("STATUS,DISTANCE_MM,650,IN_RANGE,100");
        });
    }

    void action(ActionType move) {
        if (closed || (move != ActionType.READY && epoch == 0)) return;
        String tag = move == ActionType.RFID_SCAN ? ",012345ABCD" : "";
        emit("EVT," + (++sequence) + "," + move.name() + "," + epoch + ",100" + tag);
    }

    private void emit(String line) {
        if (!closed) listener.onLine(line, System.nanoTime());
    }

    @Override public void close() { closed = true; }
}
