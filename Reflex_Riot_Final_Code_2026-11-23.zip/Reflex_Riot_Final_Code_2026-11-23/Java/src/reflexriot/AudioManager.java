package reflexriot;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.SwingUtilities;

/** Plays local WAV clips on a worker so audio never blocks the game screen. */
final class AudioManager implements AutoCloseable {
    private final Path audioDirectory;
    private final AtomicInteger generation = new AtomicInteger();
    private final ThreadPoolExecutor player = new ThreadPoolExecutor(1, 1, 0, TimeUnit.MILLISECONDS,
            new ArrayBlockingQueue<>(8), job -> {
                Thread worker = new Thread(job, "game-audio");
                worker.setDaemon(true);
                return worker;
            }, new ThreadPoolExecutor.DiscardPolicy());
    private volatile boolean muted;
    private boolean reportedFailure;

    AudioManager() { this(Paths.get("audio")); }

    AudioManager(Path audioDirectory) { this.audioDirectory = audioDirectory; }

    void setMuted(boolean value) {
        muted = value;
    }

    void play(String name) {
        play(name, null);
    }

    void play(String name, Runnable finished) {
        if (muted) {
            if (finished != null) finished.run();
            return;
        }
        int token = generation.get();
        player.execute(() -> {
            playFile(name, token, Long.MAX_VALUE);
            if (finished != null) {
                SwingUtilities.invokeLater(() -> {
                    if (token == generation.get()) finished.run();
                });
            }
        });
    }

    void playProtectedCue() {
        int token = generation.get();
        long latestStart = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(100);
        if (!muted) player.execute(() -> playFile("correct", token, latestStart));
    }

    boolean muted() { return muted; }

    void stop() {
        generation.incrementAndGet();
        player.getQueue().clear();
    }

    private void playFile(String name, int token, long latestStart) {
        if (muted || token != generation.get() || System.nanoTime() > latestStart) return;
        try (InputStream asset = openSound(name)) {
            try (AudioInputStream sound = AudioSystem.getAudioInputStream(new BufferedInputStream(asset));
                 Clip clip = AudioSystem.getClip()) {
                clip.open(sound);
                if (muted || token != generation.get() || System.nanoTime() > latestStart) return;
                clip.start();
                long end = System.nanoTime() + TimeUnit.MICROSECONDS.toNanos(clip.getMicrosecondLength());
                while (!muted && token == generation.get() && System.nanoTime() < end) {
                    Thread.sleep(10);
                }
                clip.stop();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Exception e) {
            if (!reportedFailure) {
                reportedFailure = true;
                System.err.println("Reflex Riot audio: " + e.getMessage());
            }
        }
    }

    private InputStream openSound(String name) throws IOException {
        String path = "audio/" + name + ".wav";
        InputStream resource = AudioManager.class.getResourceAsStream("/" + path);
        return resource != null ? resource : Files.newInputStream(audioDirectory.resolve(name + ".wav"));
    }

    @Override public void close() {
        stop();
        player.shutdownNow();
    }
}
