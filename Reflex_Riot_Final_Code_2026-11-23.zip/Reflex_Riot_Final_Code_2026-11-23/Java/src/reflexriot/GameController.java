package reflexriot;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

/** Connects the independent game state, station session, audio, and Swing view. */
final class GameController implements GameSession.Listener, StationClient.Listener {
    private final GameSession game;
    private final StationClient station;
    private final LeaderboardService leaderboard;
    private final AudioManager audio;
    private final LongSupplier clock;
    private final Path bridge;
    private GameView view;
    private SimulatedGateway simulator;
    private long epochCounter = System.currentTimeMillis() / 1000L;
    private long activeEpoch;
    private long previewAt;
    private long goAt;
    private long greenUntil;
    private int countdownBeep;
    private boolean headphoneAudio;
    private boolean cueFinished;
    private long feedbackEarliestEnd;
    private boolean scoreSaved;
    private boolean simulatedMatch;
    private boolean retriedEpoch;
    private String notice = "";
    private String storageNotice = "";

    GameController(GameSession game, LeaderboardService leaderboard, AudioManager audio,
                   LongSupplier clock, Path bridge) {
        this.game = game;
        this.leaderboard = leaderboard;
        this.audio = audio;
        this.clock = clock;
        this.bridge = bridge;
        station = new StationClient(this, clock);
        game.addListener(this);
    }

    void attach(GameView screen) {
        view = screen;
        game.addListener(screen);
    }

    GameSession game() { return game; }
    StationClient station() { return station; }
    LeaderboardService leaderboard() { return leaderboard; }
    String notice() { return notice; }
    String storageNotice() { return storageNotice; }
    void storageNotice(String message) { storageNotice = message; }
    boolean simulated() { return simulator != null; }
    boolean canSave() {
        return game.state() == GameSession.State.GAME_OVER && game.mode() == GameSession.Mode.SOLO
                && !simulatedMatch && !scoreSaved
                && leaderboard.qualifies(game.completedRounds(), game.completedMillis());
    }

    void connect(String port, boolean radio) {
        if (game.inMatch()) return;
        try {
            WindowsSerialGateway gateway = new WindowsSerialGateway(
                    port.trim().toUpperCase(Locale.ROOT), radio ? 9600 : 115200, bridge);
            simulator = null;
            notice = "";
            station.open(gateway);
        } catch (IllegalArgumentException e) {
            setNotice(e.getMessage());
        }
    }

    void simulate() {
        if (game.inMatch()) return;
        simulator = new SimulatedGateway();
        notice = "";
        station.open(simulator);
    }

    void disconnect() {
        if (game.inMatch()) game.interrupt("The station was disconnected.");
        simulator = null;
        station.close();
    }

    void calibrate() {
        if (!game.inMatch()) station.calibrate();
    }

    void simulatedAction(ActionType move) {
        if (simulator != null) simulator.action(move);
    }

    void start(GameSession.Mode mode) {
        if (!station.ready()) {
            setNotice("Connect and calibrate the station before starting.");
            return;
        }
        scoreSaved = false;
        simulatedMatch = simulated();
        storageNotice = "";
        game.start(mode);
    }

    void menu() { game.menu(); }
    void mute(boolean muted) { audio.setMuted(muted); }
    void headphoneAudio(boolean enabled) { headphoneAudio = enabled; }

    void save(String name) {
        if (!canSave()) return;
        try {
            scoreSaved = leaderboard.add(name, game.completedRounds(), game.completedMillis());
            storageNotice = scoreSaved ? "Score saved." : "This score is outside the top five.";
        } catch (IOException | IllegalArgumentException e) {
            storageNotice = e.getMessage();
        }
        if (view != null) view.refresh();
    }

    void tick() {
        long now = clock.getAsLong();
        station.tick(now);
        game.tick(now);
        if (game.state() == GameSession.State.COUNTDOWN) playCountdownBeep(now);
        if (cueFinished && now >= feedbackEarliestEnd) {
            cueFinished = false;
            if (game.state() == GameSession.State.ROUND_PASSED) game.roundFeedbackFinished();
        }
        if (greenUntil != 0 && now >= greenUntil && game.state() == GameSession.State.PLAYING) {
            greenUntil = 0;
            station.feedback("LED_OFF", null);
        }
        if (view != null) view.updateClock(now);
    }

    private void playCountdownBeep(long now) {
        int number = game.countdown(now);
        if (countdownBeep == number) return;
        countdownBeep = number;
        if (number == 1 && !headphoneAudio && !audio.muted()) {
            // Prepare before GO: its speaker beep must not become a CLAP action.
            // This command is asynchronous and never postpones the countdown.
            station.feedback("MUTE_CLAP,1500", null);
        }
        audio.play("countdown");
    }

    @Override public void onSensor(SensorEvent event) {
        if (event.action == ActionType.READY) {
            if (game.state() != GameSession.State.PREVIEW || event.epoch != 0 || event.receivedAt < previewAt) return;
            long now = clock.getAsLong();
            if (!station.ready()) {
                setNotice(readyInstruction());
            } else {
                game.ready(now);
            }
        } else if (activeEpoch != 0 && event.epoch == activeEpoch) {
            game.input(event.action, event.receivedAt);
        }
    }

    String readyInstruction() {
        if (!station.ready()) return "Wait for the station to finish calibration.";
        return "Press the green Ready button when you are ready.";
    }

    private void requestArm() {
        final long requested = ++epochCounter;
        if (requested > SensorEvent.UINT_MAX) {
            game.interrupt("Turn counter exhausted. Restart the application and station.");
            return;
        }
        station.arm(requested, () -> {
            if (game.state() != GameSession.State.ARMING) return;
            activeEpoch = requested;
            game.beginCountdown(clock.getAsLong());
        }, reason -> {
            if (game.state() != GameSession.State.ARMING) return;
            if (reason.equals("STALE_EPOCH") && !retriedEpoch) {
                retriedEpoch = true;
                epochCounter += 65_536L;
                requestArm();
            } else {
                game.interrupt("Station could not start the turn: " + reason);
            }
        });
    }

    @Override public void onGameSignal(GameSession.Signal signal) {
        switch (signal) {
            case PREVIEW:
                notice = "";
                previewAt = clock.getAsLong();
                audio.stop();
                station.feedback("LED_BLUE", null);
                break;
            case COUNTDOWN:
                notice = "";
                audio.stop();
                countdownBeep = 0;
                playCountdownBeep(clock.getAsLong());
                break;
            case GO_CUE:
                audio.stop();
                audio.play("go"); // Non-blocking: playback does not postpone the timer.
                break;
            case ARM_REQUEST:
                retriedEpoch = false;
                requestArm();
                break;
            case GO:
                goAt = clock.getAsLong();
                greenUntil = 0;
                break;
            case CORRECT:
                long turn = activeEpoch;
                station.feedback("LED_GREEN", () -> {
                    if (activeEpoch == turn) greenUntil = clock.getAsLong() + TimeUnit.MILLISECONDS.toNanos(180);
                });
                if (!audio.muted()) {
                    if (headphoneAudio) audio.playProtectedCue();
                    else station.muteForCue(() -> {
                        if (activeEpoch == turn) audio.playProtectedCue();
                    });
                }
                break;
            case ROUND_PASSED:
                activeEpoch = greenUntil = 0;
                audio.stop();
                cueFinished = false;
                feedbackEarliestEnd = clock.getAsLong() + TimeUnit.MILLISECONDS.toNanos(950);
                station.endInputs(false, () -> {
                    if (game.state() != GameSession.State.ROUND_PASSED) return;
                    station.feedback("LED_GREEN", null);
                    audio.play("correct", () -> {
                        if (game.tauntAfterRound()) audio.play(game.tauntClip(), () -> cueFinished = true);
                        else cueFinished = true;
                    });
                });
                break;
            case WRONG:
            case TIMEOUT:
                activeEpoch = greenUntil = 0;
                storageNotice = "";
                station.endInputs(true, null);
                audio.stop();
                audio.play(game.lossClip(signal));
                break;
            case MENU:
            case INTERRUPTED:
                activeEpoch = greenUntil = 0;
                cueFinished = false;
                notice = "";
                station.endInputs(false, null);
                audio.stop();
                break;
            default:
                break;
        }
    }

    long goAt() { return goAt; }

    @Override public void onStationChanged() {
        if (view != null) view.refresh();
    }

    @Override public void onStationFault(String detail) {
        if (game.inMatch()) game.interrupt(detail);
        else setNotice(detail);
    }

    private void setNotice(String value) {
        notice = value;
        if (view != null) view.refresh();
    }

    void close() {
        game.removeListener(this);
        if (view != null) game.removeListener(view);
        station.close(); // The Mega watchdog disarms if the app exits mid-turn.
        audio.close();
    }
}
