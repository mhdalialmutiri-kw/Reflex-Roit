package reflexriot;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.LongSupplier;

/** Strategy context: open() replaces the SensorGateway implementation at runtime.
 * Owns one firmware command in flight; called on the event thread. */
final class StationClient {
    interface Listener {
        void onStationChanged();
        void onSensor(SensorEvent event);
        void onStationFault(String detail);
    }

    private static final long REPLY_NS = TimeUnit.MILLISECONDS.toNanos(650);
    private static final long PING_NS = TimeUnit.SECONDS.toNanos(1);
    private static final long DISTANCE_NS = TimeUnit.MILLISECONDS.toNanos(1600);
    private static final long FRESH_MUTE_NS = TimeUnit.MILLISECONDS.toNanos(120);
    private static final int MAX_RETRIES = 3;

    private static final class Command {
        final String payload;
        final Runnable accepted;
        final Consumer<String> rejected;
        long id;
        long sentAt;
        int retries;

        Command(String payload, Runnable accepted, Consumer<String> rejected) {
            this.payload = payload;
            this.accepted = accepted;
            this.rejected = rejected;
        }
    }

    private final Listener listener;
    private final LongSupplier clock;
    private final Deque<Command> queue = new ArrayDeque<>();
    private SensorGateway gateway;
    private Command pending;
    private long nextId = 1 + new Random().nextInt(1_000_000_000);
    private long lastSent;
    private long lastSequence;
    private boolean synced;
    private boolean calibrated;
    private boolean sawState;
    private boolean retriedState;
    private String status = "Disconnected";
    private String distance = "UNKNOWN";
    private int millimeters = -1;
    private long distanceAt;

    StationClient(Listener listener, LongSupplier clock) {
        this.listener = listener;
        this.clock = clock;
    }

    boolean connected() { return gateway != null; }
    boolean ready() { return synced && calibrated; }
    String status() { return status; }
    int millimeters() { return millimeters; }
    String distance() { return distance; }
    boolean distanceFresh(long now) {
        return millimeters >= 0 && now - distanceAt <= DISTANCE_NS;
    }

    void open(SensorGateway next) {
        close();
        gateway = next;
        status = "Connecting to station";
        next.start(new SensorGateway.Listener() {
            @Override public void onLine(String line, long receivedAt) {
                if (gateway == next) receive(line, receivedAt);
            }

            @Override public void onFailure(String detail) {
                if (gateway == next) disconnect(detail);
            }
        });
        if (gateway == next) handshake();
    }

    void close() {
        SensorGateway previous = gateway;
        gateway = null;
        pending = null;
        queue.clear();
        synced = calibrated = sawState = false;
        retriedState = false;
        lastSequence = 0;
        distance = "UNKNOWN";
        millimeters = -1;
        status = "Disconnected";
        if (previous != null) previous.close();
        listener.onStationChanged();
    }

    private void disconnect(String detail) {
        close();
        status = detail;
        listener.onStationChanged();
        listener.onStationFault(detail);
    }

    private void handshake() {
        pending = null;
        queue.clear();
        synced = calibrated = sawState = false;
        retriedState = false;
        lastSequence = 0;
        millimeters = -1;
        distance = "UNKNOWN";
        listener.onStationChanged();
        enqueue("INPUT_DISARM", this::requestState, this::disconnect);
    }

    private void requestState() {
        enqueue("STATUS", this::completeHandshake, this::disconnect);
    }

    private void completeHandshake() {
        if (!sawState) {
            if (retriedState) disconnect("The station did not report its state. Reconnect.");
            else {
                retriedState = true;
                requestState(); // A fresh command also requests the state line again.
            }
            return;
        }
        synced = true;
        listener.onStationChanged();
    }

    void tick(long now) {
        if (gateway == null) return;
        // Process startup, opening the USB driver, and the bootloader precede the first ACK.
        long replyWait = pending != null && !synced && pending.retries == 0
                ? TimeUnit.SECONDS.toNanos(8) : REPLY_NS;
        if (pending != null && now - pending.sentAt >= replyWait) {
            if (pending.retries++ < MAX_RETRIES) sendPending(now);
            else disconnect("Station did not answer " + pending.payload + ". Reconnect.");
        } else if (synced && pending == null && now - lastSent >= PING_NS) {
            enqueue("PING", null, this::disconnect);
        }
    }

    void arm(long epoch, Runnable accepted, Consumer<String> rejected) {
        if (!ready()) {
            rejected.accept("NOT_READY");
            return;
        }
        enqueue("INPUT_ARM," + epoch, accepted, rejected);
    }

    void endInputs(boolean wrong, Runnable accepted) {
        if (!synced) return;
        queue.clear(); // Discard queued cosmetic feedback before ending an epoch.
        enqueue(wrong ? "FEEDBACK_WRONG" : "INPUT_DISARM", accepted,
                detail -> listener.onStationFault("Station rejected end-of-turn: " + detail));
    }

    void feedback(String payload, Runnable accepted) {
        if (synced) enqueue(payload, accepted, null);
    }

    void muteForCue(Runnable accepted) {
        // The supplied correct-move WAV is 1.56 s. Allow time to start and for speaker decay.
        feedback("MUTE_CLAP,1950", accepted);
    }

    void calibrate() {
        if (!synced) return;
        calibrated = false;
        status = "Calibrating. Keep the controller still.";
        listener.onStationChanged();
        enqueue("CALIBRATE", null, detail -> {
            status = "Calibration request rejected: " + detail;
            listener.onStationChanged();
        });
    }

    private void enqueue(String payload, Runnable accepted, Consumer<String> rejected) {
        if (gateway == null) return;
        if (queue.size() >= 24) {
            disconnect("Station command queue filled. Reconnect.");
            return;
        }
        queue.addLast(new Command(payload, accepted, rejected));
        sendNext();
    }

    private void sendNext() {
        if (gateway == null || pending != null || queue.isEmpty()) return;
        pending = queue.removeFirst();
        pending.id = nextId;
        nextId = nextId == SensorEvent.UINT_MAX ? 1 : nextId + 1;
        sendPending(clock.getAsLong());
    }

    private void sendPending(long now) {
        pending.sentAt = lastSent = now;
        gateway.send("CMD," + pending.id + "," + pending.payload);
    }

    private void receive(String line, long receivedAt) {
        String[] fields = line.split(",", -1);
        try {
            switch (fields[0]) {
                case "BOOT":
                    if (fields.length == 5 && "REFLEX_RIOT".equals(fields[1])) {
                        boolean wasSynced = synced;
                        status = "Station restarted";
                        handshake();
                        if (wasSynced) listener.onStationFault("The station restarted.");
                    }
                    break;
                case "ACK":
                    if (fields.length == 3 && "OK".equals(fields[2])) {
                        complete(SensorEvent.unsigned(fields[1]), null);
                    }
                    break;
                case "ERR":
                    if (fields.length == 3) {
                        long id = SensorEvent.unsigned(fields[1]);
                        if (id == 0) deviceFault(fields[2]);
                        else complete(id, fields[2]);
                    }
                    break;
                case "STATUS":
                    readStatus(fields, receivedAt);
                    break;
                case "EVT":
                    if (synced) readEvent(SensorEvent.parse(fields, receivedAt));
                    break;
                default:
                    break; // Telemetry and unrelated lines do not enter the game.
            }
        } catch (IllegalArgumentException e) {
            if ("EVT".equals(fields[0])) listener.onStationFault("Malformed station action.");
        }
    }

    private void complete(long id, String error) {
        if (pending == null || pending.id != id) return;
        Command command = pending;
        pending = null;
        // A retransmitted MUTE may replay an ACK after the original mute has ended.
        boolean fresh = !command.payload.startsWith("MUTE_CLAP,")
                || (command.retries == 0 && clock.getAsLong() - command.sentAt <= FRESH_MUTE_NS);
        if (error == null && command.accepted != null && fresh) command.accepted.run();
        if (error != null && command.rejected != null) command.rejected.accept(error);
        sendNext();
    }

    private void readStatus(String[] fields, long at) {
        if (fields.length < 2) return;
        if ("STATE".equals(fields[1]) && fields.length == 11
                && "CAL".equals(fields[3]) && "MPU".equals(fields[5])
                && "FAULT".equals(fields[7]) && "EPOCH".equals(fields[9])) {
            sawState = true;
            boolean mpu = "1".equals(fields[6]);
            boolean fault = "1".equals(fields[8]);
            calibrated = "1".equals(fields[4]) && mpu && !fault;
            if (calibrated) status = "Station ready";
            else if (!mpu) status = "MPU-6050 unavailable. Check its connection and calibrate.";
            else if (fault) status = "Station fault. Correct the issue and calibrate.";
            else status = "Waiting for calibration";
        } else if ("CALIBRATED".equals(fields[1])) {
            calibrated = true;
            status = "Station ready";
        } else if ("CALIBRATION".equals(fields[1])) {
            calibrated = false;
            status = "Calibrating. Keep the controller still.";
        } else if ("DISTANCE_MM".equals(fields[1]) && fields.length == 5) {
            millimeters = Integer.parseInt(fields[2]);
            distance = fields[3];
            distanceAt = at;
        } else {
            return;
        }
        listener.onStationChanged();
    }

    private void readEvent(SensorEvent event) {
        if (lastSequence != 0) {
            long forward = (event.sequence - lastSequence) & SensorEvent.UINT_MAX;
            if (forward == 0 || forward >= 0x8000_0000L) return;
            long expected = lastSequence == SensorEvent.UINT_MAX ? 1 : lastSequence + 1;
            if (event.sequence != expected) {
                lastSequence = event.sequence;
                listener.onStationFault("An action message was lost.");
                return;
            }
        }
        lastSequence = event.sequence;
        listener.onSensor(event);
    }

    private void deviceFault(String reason) {
        if (reason.startsWith("MPU_") || reason.startsWith("CALIBRATION_")
                || reason.equals("RFID_STREAM_ERROR") || reason.equals("TX_OVERFLOW_EVENTS_INVALID")) {
            calibrated = false;
        }
        status = "Station: " + reason;
        listener.onStationChanged();
        listener.onStationFault(status);
    }
}
