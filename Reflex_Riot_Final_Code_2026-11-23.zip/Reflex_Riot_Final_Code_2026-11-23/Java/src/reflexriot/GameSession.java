package reflexriot;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** State-pattern context and Observer-pattern subject. Owned by the Swing event thread. */
final class GameSession {
    private static final long SECOND = 1_000_000_000L;
    enum Mode { SOLO, VERSUS }

    enum Signal {
        MENU, PREVIEW, COUNTDOWN, GO_CUE, ARM_REQUEST, GO, CORRECT, ROUND_PASSED,
        WRONG, TIMEOUT, INTERRUPTED
    }

    /** Observer contract: the controller and view implement this interface. */
    interface Listener {
        void onGameSignal(Signal signal);
    }

    /** Each state handles only the input and timing it owns. */
    enum State {
        MENU,
        PREVIEW {
            @Override void ready(GameSession game, long now) {
                game.change(ARMING, Signal.ARM_REQUEST);
            }
        },
        COUNTDOWN {
            @Override void tick(GameSession game, long now) {
                if (now >= game.transitionAt) {
                    game.change(START_CUE, Signal.GO_CUE);
                    game.beginPlaying(now); // GO sound is asynchronous; the clock starts now.
                }
            }
        },
        START_CUE, ARMING,
        PLAYING {
            @Override void tick(GameSession game, long now) {
                if (now >= game.deadline) game.fail("Time expired.", Signal.TIMEOUT);
            }

            @Override void input(GameSession game, ActionType move, long receivedAt) {
                game.checkAction(move, receivedAt);
            }
        },
        ROUND_PASSED,
        GAME_OVER, INTERRUPTED;

        void ready(GameSession game, long now) {}
        void tick(GameSession game, long now) {}
        void input(GameSession game, ActionType move, long receivedAt) {}
    }

    private final Random random;
    private final Random feedbackRandom;
    private final List<ActionType> sequence = new ArrayList<>();
    private final List<Listener> listeners = new ArrayList<>();
    private State state = State.MENU;
    private Mode mode = Mode.SOLO;
    private int progress;
    private int completedRounds;
    private int player;
    private int nextVersusStarter;
    private int tauntRound;
    private long allowance;
    private long totalActive;
    private long transitionAt;
    private long startedAt;
    private long deadline;
    private String result = "";

    GameSession(Random random) {
        this(random, new Random());
    }

    GameSession(Random random, Random feedbackRandom) {
        this.random = random;
        this.feedbackRandom = feedbackRandom;
    }

    void addListener(Listener listener) {
        if (listener == null) throw new IllegalArgumentException("Observer is required");
        if (!listeners.contains(listener)) listeners.add(listener);
    }
    void removeListener(Listener listener) { listeners.remove(listener); }
    State state() { return state; }
    Mode mode() { return mode; }
    int round() { return sequence.size(); }
    int progress() { return progress; }
    int completedRounds() { return completedRounds; }
    long completedMillis() { return totalActive / 1_000_000L; }
    long allowanceNanos() { return allowance; }
    String result() { return result; }
    String playerLabel() { return mode == Mode.SOLO ? "Solo player" : "Player " + (player + 1); }
    ActionType latest() { return sequence.isEmpty() ? null : sequence.get(sequence.size() - 1); }
    boolean tauntAfterRound() { return state == State.ROUND_PASSED && round() == tauntRound; }

    boolean inMatch() {
        return state == State.PREVIEW || state == State.COUNTDOWN || state == State.START_CUE
                || state == State.ARMING || state == State.PLAYING || state == State.ROUND_PASSED;
    }

    void start(Mode selected) {
        if (inMatch()) return;
        mode = selected;
        sequence.clear();
        allowance = totalActive = 0;
        completedRounds = 0;
        tauntRound = 1 + feedbackRandom.nextInt(4);
        result = "";
        if (mode == Mode.VERSUS) {
            player = nextVersusStarter;
            nextVersusStarter = 1 - nextVersusStarter;
        }
        revealNextMove();
    }

    private static int selectionWeight(ActionType move) {
        return move == ActionType.TWIST ? 2 : 1;
    }

    private void revealNextMove() {
        ActionType previous = latest();
        // Twist has two tickets; each other move has one. Exclude the last move.
        int totalWeight = 0;
        for (ActionType candidate : ActionType.MOVES)
            if (candidate != previous) totalWeight += selectionWeight(candidate);
        int ticket = random.nextInt(totalWeight);
        ActionType next = null;
        for (ActionType candidate : ActionType.MOVES) {
            if (candidate == previous) continue;
            int weight = selectionWeight(candidate);
            if (ticket < weight) { next = candidate; break; }
            ticket -= weight;
        }
        if (previous != null && mode == Mode.VERSUS) player = 1 - player;
        sequence.add(next);
        allowance += next.seconds * SECOND;
        progress = 0;
        change(State.PREVIEW, Signal.PREVIEW);
    }

    void ready(long now) { state.ready(this, now); }
    void tick(long now) { state.tick(this, now); }
    void input(ActionType move, long at) { state.input(this, move, at); }

    void beginCountdown(long now) {
        if (state != State.ARMING) return;
        transitionAt = now + 3 * SECOND;
        change(State.COUNTDOWN, Signal.COUNTDOWN);
    }

    void roundFeedbackFinished() {
        if (state == State.ROUND_PASSED) revealNextMove();
    }

    void beginPlaying(long now) {
        if (state != State.START_CUE) return;
        startedAt = now;
        deadline = now + allowance;
        change(State.PLAYING, Signal.GO);
    }

    long remaining(long now) {
        return state == State.PLAYING ? Math.max(0, deadline - now) : allowance;
    }

    int countdown(long now) {
        long nanos = Math.max(1, transitionAt - now);
        return (int) ((nanos - 1) / SECOND + 1);
    }

    String tauntClip() { return "early_" + (1 + feedbackRandom.nextInt(8)); }

    String lossClip(Signal cause) {
        String prefix = cause == Signal.TIMEOUT ? "timeout_" : "wrong_";
        return prefix + (1 + feedbackRandom.nextInt(4));
    }

    private void checkAction(ActionType move, long receivedAt) {
        if (move == ActionType.READY || receivedAt < startedAt) return;
        if (receivedAt >= deadline) {
            fail("Time expired.", Signal.TIMEOUT);
        } else if (sequence.get(progress) != move) {
            fail("Wrong move: " + move.label + ".", Signal.WRONG);
        } else if (++progress == sequence.size()) {
            completedRounds = round();
            totalActive += receivedAt - startedAt;
            change(State.ROUND_PASSED, Signal.ROUND_PASSED);
        } else {
            emit(Signal.CORRECT);
        }
    }

    private void fail(String reason, Signal signal) {
        result = mode == Mode.VERSUS
                ? reason + " Player " + (2 - player) + " wins."
                : reason;
        change(State.GAME_OVER, signal);
    }

    void interrupt(String reason) {
        if (!inMatch()) return;
        result = reason;
        change(State.INTERRUPTED, Signal.INTERRUPTED);
    }

    void menu() {
        change(State.MENU, Signal.MENU);
    }

    private void change(State next, Signal signal) {
        state = next;
        emit(signal);
    }

    private void emit(Signal signal) {
        // Snapshot permits observers to unregister safely during a notification.
        for (Listener listener : new ArrayList<>(listeners)) listener.onGameSignal(signal);
    }
}
