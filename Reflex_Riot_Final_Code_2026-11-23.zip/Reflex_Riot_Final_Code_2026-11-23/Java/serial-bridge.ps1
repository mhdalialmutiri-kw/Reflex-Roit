param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^COM[1-9][0-9]{0,3}$')]
    [string]$Port,

    [Parameter(Mandatory = $true)]
    [ValidateSet(115200, 38400, 9600)]
    [int]$Baud
)

# Move bytes between the Windows COM port and the Java process pipes.
$ErrorActionPreference = 'Stop'
$serial = $null
$operation = 'Opening port'
try {
    $serial = New-Object System.IO.Ports.SerialPort($Port, $Baud, 'None', 8, 'One')
    $serial.Handshake = [System.IO.Ports.Handshake]::None
    $serial.ReadTimeout = 500
    $serial.WriteTimeout = 750
    $serial.DtrEnable = $true
    $serial.Open()
    # USB opening resets the Mega. Let the bootloader finish before sending commands.
    if ($Baud -eq 115200) { Start-Sleep -Milliseconds 2000 }
    $serial.DiscardInBuffer()
    $operation = 'Preparing computer input'
    $inputStream = [Console]::OpenStandardInput()
    $outputStream = [Console]::OpenStandardOutput()
    $toSerial = New-Object byte[] 256
    $fromSerial = New-Object byte[] 512
    $incoming = $inputStream.ReadAsync($toSerial, 0, $toSerial.Length)

    while ($true) {
        if ($incoming.IsCompleted) {
            $operation = 'Reading computer input'
            $size = $incoming.GetAwaiter().GetResult()
            if ($size -eq 0) { break }
            $operation = 'Sending to station'
            $serial.Write($toSerial, 0, $size)
            $operation = 'Preparing computer input'
            $incoming = $inputStream.ReadAsync($toSerial, 0, $toSerial.Length)
        }

        $operation = 'Reading from station'
        $waiting = $serial.BytesToRead
        if ($waiting -gt 0) {
            $size = $serial.Read($fromSerial, 0, [Math]::Min($waiting, $fromSerial.Length))
            $outputStream.Write($fromSerial, 0, $size)
            $outputStream.Flush()
        } else {
            Start-Sleep -Milliseconds 4
        }
    }
} catch {
    [Console]::Error.WriteLine($operation + ' - ' + $_.Exception.GetBaseException().Message)
    exit 1
} finally {
    if ($null -ne $serial) { $serial.Dispose() }
}
