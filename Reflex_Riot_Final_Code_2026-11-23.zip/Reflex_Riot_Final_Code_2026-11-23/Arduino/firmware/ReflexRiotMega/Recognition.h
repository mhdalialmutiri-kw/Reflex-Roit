#pragma once
#include "Config.h"
#include <math.h>
#include <stdint.h>

// Pure sensor logic: no Arduino/serial calls, so the same code can be tested on a PC.
namespace rr {
inline uint32_t elapsed(uint32_t now, uint32_t then) { return now - then; }
enum Action : uint8_t {
  NONE,
  TILT_LEFT,
  TILT_RIGHT,
  TWIST,
  SHAKE,
  CLAP,
  HAND_CLOSE,
  DIAL_CLOCKWISE,
  DIAL_COUNTERCLOCKWISE,
  RFID_SCAN,
  COVER_LIGHT,
  READY
};
const char *actionName(Action a);

struct Debouncer {
  bool raw = false, stable = false;
  uint32_t changed = 0;
  void reset(bool value, uint32_t now) {
    raw = stable = value;
    changed = now;
  }
  bool update(bool value, uint32_t now) {
    if (value != raw) {
      raw = value;
      changed = now;
    }
    if (stable != raw && elapsed(now, changed) >= 25) {
      stable = raw;
      return true;
    }
    return false;
  }
};

// Condition must be clear for a complete dwell before the next activation.
// reset() starts unarmed: holding an input at INPUT_ARM must not score.
struct Gate {
  bool armed = false, clearing = false, entering = false;
  uint32_t clearAt = 0, enterAt = 0;
  void reset() { armed = clearing = entering = false; }
  bool update(bool active, bool clear, uint32_t now, uint16_t clearMs, uint16_t enterMs) {
    if (clear) {
      if (!clearing) {
        clearing = true;
        clearAt = now;
      }
      if (elapsed(now, clearAt) >= clearMs)
        armed = true;
    } else
      clearing = false;
    if (active && armed) {
      if (!entering) {
        entering = true;
        enterAt = now;
      }
      if (elapsed(now, enterAt) >= enterMs) {
        armed = false;
        entering = false;
        clearing = false;
        return true;
      }
    } else
      entering = false;
    return false;
  }
};

struct Encoder {
  uint8_t previous = 0;
  int8_t total = 0;
  void reset(uint8_t value) {
    previous = value;
    total = 0;
  }
  Action update(uint8_t value);
};

struct Calibration {
  uint16_t count = 0;
  int32_t sums[3] = {0, 0, 0}, lightSum = 0;
  float gyroSum[3] = {0, 0, 0};
  int low[3] = {1023, 1023, 1023}, high[3] = {0, 0, 0};
  float gyroLow[3] = {10000, 10000, 10000}, gyroHigh[3] = {-10000, -10000, -10000};
  void add(const int a[3], const float g[3], int light);
  bool stationary() const;
};

// One wrist-rotation event per trigger hold. No fixed mounting axis or table pose.
struct Motion {
  bool collecting = false, latched = false;
  uint32_t start = 0, lastSample = 0;
  float angle[3] = {0, 0, 0};
  void reset(uint32_t now);
  Action update(const float gyro[3], bool held, uint32_t now);
};

// Parallax #28140: LF + exactly ten hexadecimal characters + CR.
struct RfidFrame {
  char tag[11] = {0};
  uint8_t length = 0;
  bool receiving = false;
  uint32_t started = 0;
  void reset() {
    length = 0;
    receiving = false;
  }
  bool feed(char c, uint32_t now);
};

// A card held in place cannot score again until a gap or a different card.
struct CardLatch {
  char last[11] = {0};
  bool seen = false;
  uint32_t seenAt = 0;
  bool observe(const char *tag, uint32_t now);
};
} // namespace rr
