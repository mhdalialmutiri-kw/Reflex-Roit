#pragma once
#include "Config.h"
#include <Arduino.h>
#include <Wire.h>

// Register-level driver from InvenSense RM-MPU-6000A. No third-party sensor library.
class Mpu6050 {
  bool writeReg(uint8_t reg, uint8_t value) {
    Wire.clearWireTimeoutFlag();
    rxBytes = 0;
    Wire.beginTransmission(cfg::MPU_ADDRESS);
    Wire.write(reg);
    Wire.write(value);
    txCode = Wire.endTransmission();
    timedOut = Wire.getWireTimeoutFlag();
    return txCode == 0 && !timedOut;
  }
  bool readOnce(uint8_t reg, uint8_t *data, uint8_t count) {
    Wire.clearWireTimeoutFlag();
    rxBytes = 0;
    Wire.beginTransmission(cfg::MPU_ADDRESS);
    Wire.write(reg);
    txCode = Wire.endTransmission(false);
    if (txCode == 0)
      rxBytes = Wire.requestFrom(cfg::MPU_ADDRESS, count);
    timedOut = Wire.getWireTimeoutFlag();
    if (txCode != 0 || rxBytes != count || timedOut)
      return false;
    for (uint8_t i = 0; i < count; ++i)
      data[i] = (uint8_t)Wire.read();
    return true;
  }

  void resetBus() {
    // The standard Mega has board-level 5 V I2C pull-ups. Use a suitable interface.
    Wire.end();
    Wire.begin();
    Wire.setClock(100000);
    Wire.setWireTimeout(3000, true);
  }

  bool readRegs(uint8_t reg, uint8_t *data, uint8_t count) {
    for (uint8_t attempt = 0; attempt < 3; ++attempt) {
      if (readOnce(reg, data, count))
        return true;
      if (attempt < 2) {
        resetBus();
        delayMicroseconds(1500);
      }
    }
    return false;
  }

public:
  uint8_t txCode = 0, rxBytes = 0;
  bool timedOut = false;
  uint8_t identity = 0;

  bool begin() {
    resetBus();
    identity = 0;
    if (!readRegs(0x75, &identity, 1) || identity != 0x68)
      return false;
    // Wake, then select ±2 g, ±500 deg/s, low-pass filtering and 100 Hz sampling.
    return writeReg(0x6B, 0x01) && writeReg(0x1A, 0x03) && writeReg(0x1B, 0x08) &&
           writeReg(0x1C, 0x00) && writeReg(0x19, 9);
  }

  bool readSample(int accel[3], float gyro[3]) {
    uint8_t data[14];
    if (!readRegs(0x3B, data, sizeof(data)))
      return false;
    for (uint8_t i = 0; i < 3; ++i) {
      const uint8_t offset = 2 * i;
      const int16_t rawAccel = signedWord(data + offset);
      const int16_t rawGyro = signedWord(data + 8 + offset);
      accel[i] = cfg::ACCEL_ZERO + rawAccel / (16384 / cfg::ACCEL_COUNTS_PER_G);
      gyro[i] = rawGyro / 65.5f;
    }
    return true;
  }

private:
  static int16_t signedWord(const uint8_t *data) {
    return (int16_t)(((uint16_t)data[0] << 8) | data[1]);
  }
};
