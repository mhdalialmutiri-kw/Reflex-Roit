#include "Recognition.h"
#include <stdlib.h>
#include <string.h>
namespace rr {
const char *actionName(Action a) {
  switch (a) {
  case TILT_LEFT:
    return "TILT_LEFT";
  case TILT_RIGHT:
    return "TILT_RIGHT";
  case TWIST:
    return "TWIST";
  case SHAKE:
    return "SHAKE";
  case CLAP:
    return "CLAP";
  case HAND_CLOSE:
    return "HAND_CLOSE";
  case DIAL_CLOCKWISE:
    return "DIAL_CLOCKWISE";
  case DIAL_COUNTERCLOCKWISE:
    return "DIAL_COUNTERCLOCKWISE";
  case RFID_SCAN:
    return "RFID_SCAN";
  case COVER_LIGHT:
    return "COVER_LIGHT";
  case READY:
    return "READY";
  default:
    return "NONE";
  }
}
Action Encoder::update(uint8_t v) {
  static const int8_t table[16] = {0, -1, 1, 0, 1, 0, 0, -1, -1, 0, 0, 1, 0, 1, -1, 0};
  if (v == previous)
    return NONE;
  if ((v ^ previous) == 3) {
    previous = v;
    total = 0;
    return NONE;
  } // Missed/invalid two-bit transition.
  int8_t step = table[(previous << 2) | v];
  previous = v;
  total += cfg::ENCODER_REVERSED ? -step : step;
  if (total >= cfg::ENCODER_TRANSITIONS_PER_CLICK) {
    total = 0;
    return DIAL_CLOCKWISE;
  }
  if (total <= -cfg::ENCODER_TRANSITIONS_PER_CLICK) {
    total = 0;
    return DIAL_COUNTERCLOCKWISE;
  }
  return NONE;
}
void Calibration::add(const int a[3], const float g[3], int light) {
  ++count;
  lightSum += light;
  for (uint8_t i = 0; i < 3; ++i) {
    sums[i] += a[i];
    gyroSum[i] += g[i];
    if (a[i] < low[i])
      low[i] = a[i];
    if (a[i] > high[i])
      high[i] = a[i];
    if (g[i] < gyroLow[i])
      gyroLow[i] = g[i];
    if (g[i] > gyroHigh[i])
      gyroHigh[i] = g[i];
  }
}
bool Calibration::stationary() const {
  if (count < cfg::CALIBRATION_SAMPLES)
    return false;
  for (uint8_t i = 0; i < 3; ++i)
    if (high[i] - low[i] > 35 || gyroHigh[i] - gyroLow[i] > 12.0f ||
        fabsf(gyroSum[i] / count) > 20.0f)
      return false;
  return true;
}
void Motion::reset(uint32_t now) {
  collecting = latched = false;
  lastSample = now;
  for (uint8_t i = 0; i < 3; ++i)
    angle[i] = 0;
}
Action Motion::update(const float g[3], bool held, uint32_t now) {
  const uint32_t dt = elapsed(now, lastSample);
  lastSample = now;
  if (!held) {
    reset(now);
    return NONE;
  }
  if (latched)
    return NONE; // Release D40 before another twist; the return cannot double-score.
  if (dt > 50) {
    reset(now);
    return NONE; // Never integrate across an I2C/scheduling gap.
  }
  float rate = 0;
  for (uint8_t i = 0; i < 3; ++i)
    if (fabsf(g[i]) > rate)
      rate = fabsf(g[i]);
  if (!collecting || elapsed(now, start) > cfg::MOTION_WINDOW_MS) {
    collecting = false;
    for (uint8_t i = 0; i < 3; ++i)
      angle[i] = 0;
    if (rate < cfg::TWIST_START_DPS)
      return NONE;
    collecting = true;
    start = now;
  }
  float rotationSquared = 0;
  for (uint8_t i = 0; i < 3; ++i) {
    if (fabsf(g[i]) >= cfg::TWIST_DEADBAND_DPS)
      angle[i] += g[i] * dt / 1000.0f;
    rotationSquared += angle[i] * angle[i];
  }
  if (rotationSquared < cfg::TWIST_ANGLE_DEG * cfg::TWIST_ANGLE_DEG)
    return NONE;
  latched = true;
  collecting = false;
  return TWIST;
}
bool RfidFrame::feed(char c, uint32_t now) {
  if (receiving && elapsed(now, started) > 150)
    reset();
  if (c == '\n') {
    length = 0;
    receiving = true;
    started = now;
    return false;
  }
  if (!receiving)
    return false;
  if (c == '\r') {
    bool ok = length == 10;
    tag[length] = 0;
    reset();
    return ok;
  }
  bool hex = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f');
  if (!hex || length >= 10) {
    reset();
    return false;
  }
  tag[length++] = (c >= 'a' && c <= 'f') ? c - 'a' + 'A' : c;
  return false;
}
bool CardLatch::observe(const char *tag, uint32_t now) {
  bool fresh = !seen || strcmp(tag, last) != 0 || elapsed(now, seenAt) >= cfg::RFID_REMOVE_MS;
  memcpy(last, tag, 11);
  seenAt = now;
  seen = true;
  return fresh;
}
} // namespace rr
