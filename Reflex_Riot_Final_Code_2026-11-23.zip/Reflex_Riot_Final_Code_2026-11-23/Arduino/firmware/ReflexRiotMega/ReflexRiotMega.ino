/* Reflex Riot Mega firmware v1.3: seven actions, Twist-only handheld, vibration disabled.
 * Reads player inputs and handles physical feedback. Java owns the game rules.
 * See README.md for upload and hardware checks, and PROTOCOL.md for messages.
 */
#include "Config.h"
#include "BinaryProtocol.h"
#include "Mpu6050.h"
#include "PulseInputs.h"
#include "Recognition.h"
#include <Arduino.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

using rr::Action;
HardwareSerial &host = RR_USE_XBEE ? Serial2 : Serial;
constexpr uint32_t HOST_BAUD = RR_USE_XBEE ? cfg::XBEE_BAUD : cfg::USB_BAUD;
constexpr const char *HOST_NAME = RR_USE_XBEE ? "XBEE" : "USB";
Mpu6050 mpu;
rr::Debouncer readyButton, triggerButton;
rr::Encoder encoder;
rr::Gate clapGate, lightGate, handGate;
rr::Motion motion;
rr::Calibration calibration;
rr::RfidFrame rfid;
rr::CardLatch card;
int accel[3] = {0, 0, 0}, baseline[3] = {0, 0, 0}, lightRaw = 0, lightBaseline = 0;
float gyro[3] = {0, 0, 0}, gyroBias[3] = {0, 0, 0};
bool armed = false, bench = false, calibrating = false, calibrated = false, mpuOk = false;
const char *fault = nullptr;
bool faultAnnounced = false, telemetry = false;
uint32_t epoch = 0, lastEpoch = 0, eventSequence = 0, lastHost = 0;
uint32_t calStart = 0, sampleAt = 0, rawAt = 0, statusAt = 0, clapMuteAt = 0;
uint16_t clapMuteMs = 0;
uint16_t micLow = 1023, micHigh = 0, soundLevel = 0, micThreshold = 18;
uint32_t micWindowAt = 0, micCalSum = 0;
uint16_t micCalCount = 0, micCalMax = 0;

// Bounded transmit queue: writing only available bytes avoids sensor stalls.
const uint8_t TX_SLOTS = 8, TX_SIZE = binary::MAX_PAYLOAD + 7;
uint8_t tx[TX_SLOTS][TX_SIZE], txLength[TX_SLOTS];
uint8_t txHead = 0, txTail = 0, txCount = 0, txOffset = 0;

uint8_t encoderState() { return (digitalRead(cfg::ENC_CLK) << 1) | digitalRead(cfg::ENC_DT); }
void writeLed(uint8_t r, uint8_t g, uint8_t b) {
  analogWrite(cfg::RED, cfg::RGB_COMMON_ANODE ? 255 - r : r);
  analogWrite(cfg::GREEN, cfg::RGB_COMMON_ANODE ? 255 - g : g);
  analogWrite(cfg::BLUE, cfg::RGB_COMMON_ANODE ? 255 - b : b);
}
void resetRecognition(uint32_t now) {
  clapGate.reset();
  lightGate.reset();
  handGate.reset();
  motion.reset(now);
  encoder.reset(encoderState());
  rfid.reset();
  // Deliberately preserve card latch: a held card must be removed before reuse.
}
void stopVibration() {
  // Do not source or sink motor current, or enable the internal pull-up.
  pinMode(cfg::VIBRATION, INPUT);
  digitalWrite(cfg::VIBRATION, LOW);
}
void stopInputs() {
  stopVibration();
  armed = false;
  bench = false;
  epoch = 0;
  resetRecognition(millis());
}
void latchFault(const char *reason) {
  fault = reason;
  faultAnnounced = false;
  stopInputs();
  writeLed(100, 0, 0);
}
bool packet(uint8_t type, const uint8_t *payload, uint8_t length) {
  if (txCount == TX_SLOTS) {
    latchFault("TX_OVERFLOW_EVENTS_INVALID");
    return false;
  }
  txLength[txHead] = binary::frame(tx[txHead], type, payload, length);
  txHead = (txHead + 1) % TX_SLOTS;
  ++txCount;
  return true;
}
bool line(const char *format, ...) {
  char payload[binary::MAX_PAYLOAD + 1];
  va_list args;
  va_start(args, format);
  int n = vsnprintf(payload, sizeof(payload), format, args);
  va_end(args);
  if (n < 0 || n > binary::MAX_PAYLOAD) {
    latchFault("TX_OVERFLOW_EVENTS_INVALID");
    return false;
  }
  return packet(binary::MESSAGE, (const uint8_t *)payload, (uint8_t)n);
}
void drainTx() {
  uint8_t budget = 32;
  while (txCount && host.availableForWrite() > 0 && budget--) {
    host.write(tx[txTail][txOffset++]);
    if (txOffset == txLength[txTail]) {
      txOffset = 0;
      txTail = (txTail + 1) % TX_SLOTS;
      --txCount;
    }
  }
}
void event(Action a, const char *tag = nullptr) {
  if (a == rr::NONE || calibrating || !calibrated || fault)
    return;
  if (a != rr::READY && !(armed || bench))
    return;
  if (++eventSequence == 0)
    ++eventSequence;
  uint8_t payload[23];
  payload[0] = (uint8_t)a;
  binary::put32(payload + 1, eventSequence);
  binary::put32(payload + 5, epoch);
  binary::put32(payload + 9, millis());
  if (tag) memcpy(payload + 13, tag, 10);
  packet(binary::EVENT, payload, tag ? 23 : 13);
}

bool sonarWaiting = false;
uint32_t sonarSentUs = 0, sonarAt = 0;
int distanceMm = -1;
const char *distanceState = "UNKNOWN";
void updateDistance(int mm, uint32_t now) {
  distanceMm = mm;
  distanceState = mm < 0                     ? "UNKNOWN"
                  : mm <= cfg::HAND_EXIT_MM  ? "HAND_OCCLUDED"
                  : mm < cfg::PLAYER_NEAR_MM ? "TOO_CLOSE"
                  : mm > cfg::PLAYER_FAR_MM  ? "TOO_FAR"
                                             : "IN_RANGE";
  if (mm < 0) {
    handGate.reset();
    return;
  }
  if (handGate.update(mm >= 20 && mm <= cfg::HAND_ENTER_MM, mm >= cfg::HAND_EXIT_MM, now, 200, 65))
    event(rr::HAND_CLOSE);
}
void sonarTask(uint32_t now) {
  uint32_t width;
  const bool done = pulseInputs::takeEcho(width);
  if (sonarWaiting && done) {
    sonarWaiting = false;
    // Sound speed approx 343 m/s; distance = round-trip duration * 0.1715 mm/us.
    int mm = width <= 25000 ? (int)((width * 343UL + 1000) / 2000) : -1;
    updateDistance(mm >= 20 && mm <= 4000 ? mm : -1, now);
  } else if (sonarWaiting && (uint32_t)(micros() - sonarSentUs) > 25000UL) {
    sonarWaiting = false;
    pulseInputs::clearEcho();
    updateDistance(-1, now);
  }
  if (!sonarWaiting && rr::elapsed(now, sonarAt) >= 70) {
    sonarAt = now;
    pulseInputs::clearEcho();
    digitalWrite(cfg::SONAR_TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(cfg::SONAR_TRIG, LOW);
    sonarSentUs = micros();
    sonarWaiting = true;
  }
}

void calibrationStart() {
  stopInputs();
  calibrated = false;
  calibrating = false;
  fault = nullptr;
  faultAnnounced = false;
  calibration = rr::Calibration();
  micCalSum = micCalCount = micCalMax = 0;
  mpuOk = mpu.begin();
  if (!mpuOk) {
    writeLed(100, 0, 0);
    line("RAW,MPU_INIT,ID,%u,TX_CODE,%u,RX_BYTES,%u,TIMEOUT,%u", (unsigned)mpu.identity,
         (unsigned)mpu.txCode, (unsigned)mpu.rxBytes, (unsigned)mpu.timedOut);
    line("ERR,0,MPU_NOT_FOUND");
    return;
  }
  calStart = millis();
  calibrating = true;
  writeLed(80, 40, 0);
  line("STATUS,CALIBRATION,KEEP_STILL_UNCOVER_LIGHT");
}
void sampleTask(uint32_t now) {
  if (!mpuOk || (calibrating && rr::elapsed(now, calStart) < cfg::CALIBRATION_SETTLE_MS))
    return;
  if (rr::elapsed(now, sampleAt) < 10)
    return;
  sampleAt = now;
  // Let the ADC settle after switching from the microphone to the light sensor.
  analogRead(A3);
  lightRaw = analogRead(A3);
  float rawGyro[3];
  if (!mpu.readSample(accel, rawGyro)) {
    mpuOk = false;
    calibrated = calibrating = false;
    stopInputs();
    writeLed(100, 0, 0);
    line("RAW,MPU_I2C,TX_CODE,%u,RX_BYTES,%u,TIMEOUT,%u", (unsigned)mpu.txCode,
         (unsigned)mpu.rxBytes, (unsigned)mpu.timedOut);
    line("ERR,0,MPU_READ_FAILED");
    return;
  }
  for (uint8_t i = 0; i < 3; ++i)
    gyro[i] = rawGyro[i] - gyroBias[i];
  if (calibrating) {
    if (triggerButton.stable || readyButton.stable) {
      calibrating = false;
      line("ERR,0,CALIBRATION_BUTTON_HELD");
      writeLed(100, 0, 0);
      return;
    }
    calibration.add(accel, rawGyro, lightRaw);
    if (calibration.count < cfg::CALIBRATION_SAMPLES)
      return;
    calibrating = false;
    // At rest the acceleration vector should be close to one g in any orientation.
    int32_t gravitySquared = 0;
    for (uint8_t i = 0; i < 3; ++i) {
      baseline[i] = calibration.sums[i] / calibration.count;
      const int32_t component = baseline[i] - cfg::ACCEL_ZERO;
      gravitySquared += component * component;
    }
    const int minGravity = cfg::ACCEL_COUNTS_PER_G * 3 / 4;
    const int maxGravity = cfg::ACCEL_COUNTS_PER_G * 5 / 4;
    const bool gravityOk = gravitySquared >= minGravity * minGravity &&
                           gravitySquared <= maxGravity * maxGravity;
    const bool stationary = calibration.stationary();
    const int averageLight = calibration.lightSum / calibration.count;
    if (!gravityOk || !stationary || averageLight < cfg::LIGHT_MIN_BASELINE || micCalMax > 100) {
      line("RAW,CAL_CHECK,GRAVITY_OK,%u,STILL_OK,%u,LIGHT,%d,MIC_PEAK,%u",
           (unsigned)gravityOk, (unsigned)stationary, averageLight, micCalMax);
      line("ERR,0,CALIBRATION_FAILED_CHECK_RAW");
      writeLed(100, 0, 0);
      return;
    }
    for (uint8_t i = 0; i < 3; ++i)
      gyroBias[i] = calibration.gyroSum[i] / calibration.count;
    lightBaseline = calibration.lightSum / calibration.count;
    micThreshold = (micCalCount ? micCalSum / micCalCount : 0) * 3 + 12;
    if (micThreshold < 18)
      micThreshold = 18;
    calibrated = true;
    resetRecognition(now);
    writeLed(0, 0, 40);
    line("STATUS,CALIBRATED,LIGHT,%d,MIC_THRESHOLD,%u", lightBaseline, micThreshold);
    return;
  }
  if (!calibrated)
    return;
  int drop = lightBaseline * cfg::LIGHT_DROP_PERCENT / 100;
  if (drop < cfg::LIGHT_MIN_DROP)
    drop = cfg::LIGHT_MIN_DROP;
  int enter = lightBaseline - drop, exit = lightBaseline - drop / 2;
  if (lightGate.update(lightRaw < enter, lightRaw > exit, now, 80, 100))
    event(rr::COVER_LIGHT);
  Action action =
      motion.update(gyro, triggerButton.stable && (armed || bench), now);
  if (action != rr::NONE)
    event(action);
}
void micTask(uint32_t now) {
  uint16_t value = analogRead(A1);
  if (value < micLow)
    micLow = value;
  if (value > micHigh)
    micHigh = value;
  if (rr::elapsed(now, micWindowAt) < 12)
    return;
  micWindowAt = now;
  soundLevel = micHigh - micLow;
  micLow = 1023;
  micHigh = 0;
  if (calibrating && rr::elapsed(now, calStart) >= cfg::CALIBRATION_SETTLE_MS) {
    micCalSum += soundLevel;
    ++micCalCount;
    if (soundLevel > micCalMax)
      micCalMax = soundLevel;
  }
  bool muted = clapMuteMs && rr::elapsed(now, clapMuteAt) < clapMuteMs;
  if (muted || calibrating || !calibrated) {
    clapGate.reset();
    return;
  }
  if (clapGate.update(soundLevel >= micThreshold, soundLevel < micThreshold / 2, now, 120, 0))
    event(rr::CLAP);
}
void buttonEncoderTask(uint32_t now) {
  if (readyButton.update(digitalRead(cfg::READY) == LOW, now) && readyButton.stable)
    event(rr::READY);
  triggerButton.update(digitalRead(cfg::TRIGGER) == LOW, now);
  Action a = encoder.update(encoderState());
  if (a != rr::NONE)
    event(a);
}
void rfidTask(uint32_t now) {
  if (pulseInputs::takeRfidError()) {
    rfid.reset();
    if (armed || bench)
      latchFault("RFID_STREAM_ERROR");
    else
      line("ERR,0,RFID_STREAM_ERROR");
  }
  for (uint8_t i = 0; i < 24; ++i) {
    const int value = pulseInputs::readRfidByte();
    if (value < 0)
      break;
    if (rfid.feed((char)value, now)) {
      bool fresh = card.observe(rfid.tag, now); // Track held cards even while disarmed.
      if (fresh)
        event(rr::RFID_SCAN, rfid.tag);
    }
  }
}

// Command line parser and bounded replay cache. Commands are never evaluated as code.
char rx[81];
uint8_t rxLen = 0;
bool rxDiscard = false;
uint32_t rxAt = 0;
struct Cached {
  uint32_t id = 0;
  char request[81] = {0};
  char result[30] = {0};
};
Cached cache[8];
uint8_t cacheNext = 0;
bool number(const char *text, uint32_t &value) {
  if (!*text)
    return false;
  value = 0;
  for (; *text; ++text) {
    if (*text < '0' || *text > '9')
      return false;
    uint8_t digit = *text - '0';
    if (value > (UINT32_MAX - digit) / 10)
      return false;
    value = value * 10 + digit;
  }
  return true;
}
void status() {
  line("STATUS,STATE,%s,CAL,%u,MPU,%u,FAULT,%u,EPOCH,%lu",
       armed   ? "ARMED"
       : bench ? "TEST"
               : "DISARMED",
       (unsigned)calibrated, (unsigned)mpuOk, (unsigned)(fault != nullptr), (unsigned long)epoch);
}
const char *execute(char **f, uint8_t count, uint32_t now) {
  const char *op = f[2];
  if (!strcmp(op, "INPUT_ARM")) {
    uint32_t requested = 0;
    if (count != 4 || !number(f[3], requested) || requested == 0)
      return "BAD_ARGUMENT";
    if (!calibrated || !mpuOk || fault || calibrating)
      return "NOT_READY";
    if (bench)
      return "TEST_MODE";
    if (armed)
      return "ALREADY_ARMED";
    if (requested <= lastEpoch)
      return "STALE_EPOCH";
    stopVibration();
    resetRecognition(now);
    epoch = lastEpoch = requested;
    armed = true;
    lastHost = now;
    writeLed(0, 0, 0);
    return "OK";
  }
  if (!strcmp(op, "INPUT_DISARM")) {
    if (count != 3)
      return "BAD_ARGUMENT";
    stopInputs();
    writeLed(0, 0, 40);
    return "OK";
  }
  if (!strcmp(op, "MUTE_CLAP")) {
    uint32_t duration;
    if (count != 4 || !number(f[3], duration) || duration > 2000)
      return "BAD_ARGUMENT";
    clapMuteMs = duration;
    clapMuteAt = now;
    clapGate.reset();
    return "OK";
  }
  if (!strcmp(op, "TELEMETRY")) {
    if (count != 4 || (strcmp(f[3], "ON") && strcmp(f[3], "OFF")))
      return "BAD_ARGUMENT";
    telemetry = !strcmp(f[3], "ON");
    return "OK";
  }
  if (count != 3)
    return "BAD_ARGUMENT";
  if (!strcmp(op, "PING"))
    return "OK";
  if (!strcmp(op, "STATUS")) {
    status();
    return "OK";
  }
  if (!strcmp(op, "CALIBRATE")) {
    if (armed || bench || calibrating)
      return "BUSY";
    calibrationStart();
    return "OK";
  }
  if (!strcmp(op, "TEST_ON")) {
    if (armed)
      return "BUSY";
    if (!calibrated || !mpuOk || fault || calibrating)
      return "NOT_READY";
    stopInputs();
    bench = true;
    writeLed(70, 30, 0);
    return "OK";
  }
  if (!strcmp(op, "TEST_OFF")) {
    stopInputs();
    writeLed(0, 0, 40);
    return "OK";
  }
  if (!strcmp(op, "LED_RED")) {
    writeLed(100, 0, 0);
    return "OK";
  }
  if (!strcmp(op, "LED_GREEN")) {
    writeLed(0, 100, 0);
    return "OK";
  }
  if (!strcmp(op, "LED_BLUE")) {
    writeLed(0, 0, 100);
    return "OK";
  }
  if (!strcmp(op, "LED_OFF")) {
    writeLed(0, 0, 0);
    return "OK";
  }
  if (!strcmp(op, "FEEDBACK_WRONG")) {
    if (!calibrated || !mpuOk || fault || calibrating)
      return "NOT_READY";
    if (armed)
      stopInputs();
    writeLed(100, 0, 0);
    stopVibration(); // User requested no vibration, including wrong-move feedback.
    return "OK";
  }
  return "UNKNOWN_COMMAND";
}
void command(uint32_t now) {
  char original[81];
  strcpy(original, rx);
  if (!rxLen || rx[0] == ',' || rx[rxLen - 1] == ',' || strstr(rx, ",,")) {
    line("ERR,0,BAD_FRAME");
    return;
  }
  char *fields[6];
  uint8_t count = 0;
  char *save = nullptr;
  for (char *p = strtok_r(rx, ",", &save); p; p = strtok_r(nullptr, ",", &save)) {
    if (count == 6) {
      line("ERR,0,BAD_FRAME");
      return;
    }
    fields[count++] = p;
  }
  uint32_t id;
  if (count < 3 || strcmp(fields[0], "CMD") || !number(fields[1], id) || !id) {
    line("ERR,0,BAD_FRAME");
    return;
  }
  for (uint8_t i = 0; i < 8; ++i)
    if (cache[i].id == id) {
      if (strcmp(cache[i].request, original)) {
        line("ERR,%lu,ID_REUSED", (unsigned long)id);
        return;
      }
      if (!strcmp(cache[i].result, "OK")) {
        lastHost = now;
        line("ACK,%lu,OK", (unsigned long)id);
      } else
        line("ERR,%lu,%s", (unsigned long)id, cache[i].result);
      return;
    }
  const char *result = execute(fields, count, now);
  Cached &c = cache[cacheNext];
  cacheNext = (cacheNext + 1) % 8;
  c.id = id;
  strcpy(c.request, original);
  strncpy(c.result, result, sizeof(c.result) - 1);
  c.result[sizeof(c.result) - 1] = 0;
  if (!strcmp(result, "OK")) {
    lastHost = now;
    line("ACK,%lu,OK", (unsigned long)id);
  } else
    line("ERR,%lu,%s", (unsigned long)id, result);
}
void serialTask(uint32_t now) {
  if ((rxLen || rxDiscard) && rr::elapsed(now, rxAt) > 500) {
    rxLen = 0;
    rxDiscard = true;
  }
  uint8_t budget = 32;
  while (host.available() && budget--) {
    char c = (char)host.read();
    rxAt = now;
    if (c == '\n') {
      if (rxDiscard)
        line("ERR,0,RX_OVERSIZE_OR_TIMEOUT");
      else {
        if (rxLen && rx[rxLen - 1] == '\r')
          --rxLen;
        rx[rxLen] = 0;
        if (rxLen)
          command(now);
      }
      rxLen = 0;
      rxDiscard = false;
    } else if (!rxDiscard) {
      if (rxLen >= 80 || (c != '\r' && (c < 32 || c > 126))) {
        rxDiscard = true;
        rxLen = 0;
      } else
        rx[rxLen++] = c;
    }
  }
}
void reports(uint32_t now) {
  if (fault && !faultAnnounced && txCount < TX_SLOTS - 2) {
    faultAnnounced = true;
    line("ERR,0,%s", fault);
  }
  if (rr::elapsed(now, statusAt) >= 500 && txCount < TX_SLOTS - 2) {
    statusAt = now;
    line("STATUS,DISTANCE_MM,%d,%s,%lu", distanceMm, distanceState, (unsigned long)now);
  }
  if (telemetry && rr::elapsed(now, rawAt) >= 50 && txCount < TX_SLOTS - 4) {
    rawAt = now;
    line("RAW,ACCEL_COUNTS,%d,%d,%d,LIGHT,%d,SOUND,%u", accel[0], accel[1], accel[2], lightRaw,
         soundLevel);
    line("RAW,GYRO_DPS_X10,%d,%d,%d,TRIGGER,%u", (int)(gyro[0] * 10), (int)(gyro[1] * 10),
         (int)(gyro[2] * 10), triggerButton.stable);
  }
}
void setup() {
  pinMode(cfg::READY, INPUT_PULLUP);
  pinMode(cfg::TRIGGER, INPUT_PULLUP);
  pinMode(cfg::ENC_CLK, INPUT_PULLUP);
  pinMode(cfg::ENC_DT, INPUT_PULLUP);
  pinMode(cfg::RED, OUTPUT);
  pinMode(cfg::GREEN, OUTPUT);
  pinMode(cfg::BLUE, OUTPUT);
  writeLed(0, 0, 0);
  stopVibration();
  pinMode(cfg::SONAR_TRIG, OUTPUT);
  digitalWrite(cfg::SONAR_TRIG, LOW);
  pulseInputs::begin();
  host.begin(HOST_BAUD);
  uint32_t now = millis();
  readyButton.reset(digitalRead(cfg::READY) == LOW, now);
  triggerButton.reset(digitalRead(cfg::TRIGGER) == LOW, now);
  encoder.reset(encoderState());
  micWindowAt = now;
  line("BOOT,REFLEX_RIOT,1.3,%s,%lu", HOST_NAME, (unsigned long)HOST_BAUD);
  calibrationStart();
}
void loop() {
  uint32_t now = millis();
  drainTx();
  if (armed && rr::elapsed(now, lastHost) >= cfg::LINK_TIMEOUT_MS) {
    stopInputs();
    writeLed(100, 0, 0);
    line("ERR,0,HOST_TIMEOUT_DISARMED");
  }
  serialTask(now);
  now = millis(); // CALIBRATE can reset timestamps while processing a command.
  buttonEncoderTask(now);
  sonarTask(now);
  micTask(now);
  sampleTask(now);
  rfidTask(now);
  reports(now);
  drainTx();
}
