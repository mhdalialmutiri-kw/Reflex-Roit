#pragma once
#include <stdint.h>

namespace pulseInputs {
void begin();
void clearEcho();
bool takeEcho(uint32_t &widthUs);
int readRfidByte(); // Returns -1 when the receive queue is empty.
bool takeRfidError(); // Discards queued bytes when the stream loses framing or overflows.
}
