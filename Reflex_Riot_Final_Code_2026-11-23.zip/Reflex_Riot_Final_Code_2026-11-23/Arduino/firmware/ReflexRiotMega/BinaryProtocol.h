#pragma once
#include <stdint.h>

// Frame: A5 5A, version 1, type, length, payload, CRC16-CCITT (big endian).
// CRC covers version through payload. Maximum payload is 98 bytes.
namespace binary {
constexpr uint8_t EVENT = 1, MESSAGE = 2, MAX_PAYLOAD = 98;
inline uint16_t crcByte(uint16_t crc, uint8_t value) {
  crc ^= (uint16_t)value << 8;
  for (uint8_t bit = 0; bit < 8; ++bit)
    crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021) : (uint16_t)(crc << 1);
  return crc;
}
inline void put32(uint8_t *dest, uint32_t value) {
  for (uint8_t i = 0; i < 4; ++i)
    dest[i] = (uint8_t)(value >> (24 - 8 * i));
}
inline uint8_t frame(uint8_t *dest, uint8_t type, const uint8_t *payload, uint8_t length) {
  dest[0] = 0xA5;
  dest[1] = 0x5A;
  dest[2] = 1;
  dest[3] = type;
  dest[4] = length;
  uint16_t crc = 0xFFFF;
  for (uint8_t i = 2; i < 5; ++i) crc = crcByte(crc, dest[i]);
  for (uint8_t i = 0; i < length; ++i) {
    dest[5 + i] = payload[i];
    crc = crcByte(crc, payload[i]);
  }
  dest[5 + length] = crc >> 8;
  dest[6 + length] = crc;
  return length + 7;
}
}
