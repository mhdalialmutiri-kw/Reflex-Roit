#include "PulseInputs.h"
#include "Config.h"
#include <Arduino.h>
#include <avr/interrupt.h>
#include <util/atomic.h>

namespace {
// On the Mega, D10/PB4 and D11/PB5 share PCINT0. Use one ISR for both edges.
constexpr uint8_t ECHO_MASK = _BV(PB4);
constexpr uint8_t RFID_MASK = _BV(PB5);
constexpr uint16_t BIT_TICKS = (F_CPU / 8 + cfg::RFID_BAUD / 2) / cfg::RFID_BAUD;
constexpr uint16_t FIRST_SAMPLE_TICKS = (3UL * F_CPU / 16 + cfg::RFID_BAUD / 2) / cfg::RFID_BAUD;
constexpr uint8_t RFID_QUEUE_SIZE = 32;
static_assert(cfg::SONAR_ECHO == 10 && cfg::RFID_RX == 11, "Update the Port B mapping if moved");

volatile uint8_t previousPins;
volatile bool echoRisen, echoDone;
volatile uint32_t echoRiseUs, echoWidthUs;
volatile uint8_t rfidHead, rfidTail, rfidQueue[RFID_QUEUE_SIZE];
volatile bool rfidError;
// Accessed only by the two ISRs. Bit 8 is the stop bit.
uint8_t rfidBit, rfidByte;

uint8_t nextIndex(uint8_t index) {
  return (index + 1) % RFID_QUEUE_SIZE;
}
}

void pulseInputs::begin() {
  pinMode(cfg::SONAR_ECHO, INPUT);
  pinMode(cfg::RFID_RX, INPUT_PULLUP);
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    // Free-running Timer5, prescaler 8. RGB PWM on D3/D5/D6 uses other timers.
    TCCR5A = 0;
    TCCR5B = _BV(CS51);
    TIMSK5 &= ~_BV(OCIE5A);
    previousPins = PINB;
    PCMSK0 |= _BV(PCINT4) | _BV(PCINT5);
    PCIFR = _BV(PCIF0);
    PCICR |= _BV(PCIE0);
  }
}

void pulseInputs::clearEcho() {
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    echoRisen = false;
    echoDone = false;
  }
}

bool pulseInputs::takeEcho(uint32_t &widthUs) {
  bool available;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    available = echoDone;
    widthUs = echoWidthUs;
    echoDone = false;
  }
  return available;
}

int pulseInputs::readRfidByte() {
  const uint8_t tail = rfidTail;
  if (tail == rfidHead)
    return -1;
  const uint8_t value = rfidQueue[tail];
  rfidTail = nextIndex(tail);
  return value;
}

bool pulseInputs::takeRfidError() {
  bool error;
  ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
    error = rfidError;
    if (error) {
      rfidTail = rfidHead;
      rfidError = false;
    }
  }
  return error;
}

ISR(PCINT0_vect) {
  const uint8_t pins = PINB;
  const uint8_t changed = pins ^ previousPins;
  previousPins = pins;

  if ((changed & RFID_MASK) && !(pins & RFID_MASK) && !(TIMSK5 & _BV(OCIE5A))) {
    rfidBit = 0;
    rfidByte = 0;
    OCR5A = TCNT5 + FIRST_SAMPLE_TICKS;
    TIFR5 = _BV(OCF5A);
    TIMSK5 |= _BV(OCIE5A);
  }

  if (changed & ECHO_MASK) {
    if (pins & ECHO_MASK) {
      echoRiseUs = micros();
      echoRisen = true;
    } else if (echoRisen) {
      echoWidthUs = micros() - echoRiseUs;
      echoDone = true;
      echoRisen = false;
    }
  }
}

ISR(TIMER5_COMPA_vect) {
  const bool high = (PINB & RFID_MASK) != 0;
  if (rfidBit < 8) {
    if (high)
      rfidByte |= _BV(rfidBit);
    ++rfidBit;
    OCR5A += BIT_TICKS;
    return;
  }

  TIMSK5 &= ~_BV(OCIE5A);
  const uint8_t next = nextIndex(rfidHead);
  if (!high || next == rfidTail) {
    rfidError = true;
    return;
  }
  rfidQueue[rfidHead] = rfidByte;
  rfidHead = next;
}
