#pragma once
#include <stdint.h>

#ifndef RR_USE_XBEE
#define RR_USE_XBEE 0 // Set to 1 after configuring both XBee radios for transparent mode.
#endif

namespace cfg {
constexpr uint32_t USB_BAUD = 115200;
constexpr uint32_t XBEE_BAUD = 9600; // Must match both radios and Java's XBee option.
constexpr uint32_t RFID_BAUD = 2400;
constexpr uint8_t READY = 50, TRIGGER = 40, RED = 6, GREEN = 5, BLUE = 3;
constexpr uint8_t ENC_CLK = 7, ENC_DT = 8, SONAR_TRIG = 9, SONAR_ECHO = 10;
constexpr uint8_t RFID_RX = 11, VIBRATION = 23;
// Vibration is disabled: D23 stays an input with its pull-up OFF.
constexpr bool RGB_COMMON_ANODE = false; // Matches the previously working diagnostic.
constexpr bool ENCODER_REVERSED = false;
constexpr int ENCODER_TRANSITIONS_PER_CLICK = 2; // Two transitions per physical detent.
constexpr uint8_t MPU_ADDRESS = 0x68;            // AD0 LOW; HIGH selects 0x69.
// Twist is the sole handheld action; wrist rotation on any MPU axis is accepted.
constexpr int ACCEL_ZERO = 512, ACCEL_COUNTS_PER_G = 64;
constexpr uint32_t MOTION_WINDOW_MS = 600;
constexpr float TWIST_START_DPS = 25.0f, TWIST_DEADBAND_DPS = 12.0f;
constexpr float TWIST_ANGLE_DEG = 18.0f;
constexpr int LIGHT_MIN_DROP = 6;
constexpr int LIGHT_MIN_BASELINE = 24;
constexpr uint8_t LIGHT_DROP_PERCENT = 20; // Cover causes lower readings in the tested family.
constexpr int HAND_ENTER_MM = 120, HAND_EXIT_MM = 200;
constexpr int PLAYER_NEAR_MM = 300, PLAYER_FAR_MM = 1200;
constexpr uint32_t LINK_TIMEOUT_MS = 3500;
constexpr uint16_t CALIBRATION_SAMPLES = 250; // 2.5 seconds at 100 Hz, after settling.
constexpr uint32_t CALIBRATION_SETTLE_MS = 1000;
constexpr uint32_t RFID_REMOVE_MS = 1000;
static_assert(ENCODER_TRANSITIONS_PER_CLICK > 0, "Encoder transition count must be positive");
} // namespace cfg
