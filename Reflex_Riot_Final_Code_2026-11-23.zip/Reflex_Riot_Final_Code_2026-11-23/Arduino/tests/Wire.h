#pragma once
#include <stdint.h>
#include <vector>
struct FakeWire {
  bool fail = false;
  uint8_t shortReads = 0;
  uint8_t who = 0x68, reg = 0;
  uint8_t registers[256] = {0};
  int16_t rawAccel[3] = {0, 0, 16384};
  int16_t rawGyro[3] = {0, 0, 0};
  std::vector<uint8_t> tx, rx;
  size_t index = 0;
  void begin() {}
  void end() {}
  void setClock(uint32_t) {}
  void setWireTimeout(uint32_t, bool) {}
  void clearWireTimeoutFlag() {}
  bool getWireTimeoutFlag() { return false; }
  void beginTransmission(uint8_t) { tx.clear(); }
  void write(uint8_t b) { tx.push_back(b); }
  uint8_t endTransmission(bool = true) {
    if (fail)
      return 4;
    if (tx.size()) {
      reg = tx[0];
      if (tx.size() > 1)
        registers[reg] = tx[1];
    }
    return 0;
  }
  uint8_t requestFrom(uint8_t, uint8_t n) {
    rx.clear();
    index = 0;
    if (fail)
      return 0;
    if (shortReads > 0) {
      --shortReads;
      return 0;
    }
    if (reg == 0x75)
      rx.push_back(who);
    else if (reg == 0x3B) {
      for (int16_t v : rawAccel) {
        rx.push_back((uint16_t)v >> 8);
        rx.push_back(v & 255);
      }
      rx.push_back(0); // Temperature is between acceleration and gyroscope data.
      rx.push_back(0);
      for (int16_t v : rawGyro) {
        rx.push_back((uint16_t)v >> 8);
        rx.push_back(v & 255);
      }
    } else
      for (uint8_t i = 0; i < n; ++i)
        rx.push_back(registers[(uint8_t)(reg + i)]);
    return (uint8_t)rx.size();
  }
  int read() { return rx[index++]; }
};
extern FakeWire Wire;
