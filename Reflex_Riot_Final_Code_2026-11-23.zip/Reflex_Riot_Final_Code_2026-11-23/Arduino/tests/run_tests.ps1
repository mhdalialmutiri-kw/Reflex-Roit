param(
    [string]$Compiler = 'clang++',
    [string]$BuildDir = (Join-Path $PSScriptRoot 'build')
)
$ErrorActionPreference = 'Stop'
$packageRoot = Split-Path -Parent $PSScriptRoot
New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
$sketch = Join-Path $packageRoot 'firmware\ReflexRiotMega'
$sources = @((Join-Path $PSScriptRoot 'test_firmware.cpp'),
    (Join-Path $sketch 'Recognition.cpp'), (Join-Path $sketch 'PulseInputs.cpp'))
foreach ($useXBee in @(0, 1)) {
    $exe = Join-Path $buildDir "test_firmware_$useXBee.exe"
    $arguments = @('-std=c++17', '-O0', '-Wall', '-Wextra', '-Werror',
        "-DRR_USE_XBEE=$useXBee", '-I', $PSScriptRoot) + $sources + @('-o', $exe)
    if ([IO.Path]::GetFileNameWithoutExtension($Compiler) -eq 'zig') {
        $arguments = @('c++') + $arguments
    }
    & $Compiler @arguments
    if ($LASTEXITCODE -ne 0) { throw 'Computer test compilation failed' }
    & $exe
    if ($LASTEXITCODE -ne 0) { throw 'Computer tests failed' }
}
