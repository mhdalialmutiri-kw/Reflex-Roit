#pragma once
// Computer-only Arduino adapter. Never copy into the sketch directory.
#include <algorithm>
#include <deque>
#include <stddef.h>
#include <stdint.h>
#include <string>
#include "DecodedOutput.h"
constexpr int LOW = 0, HIGH = 1, INPUT = 0, OUTPUT = 1, INPUT_PULLUP = 2;
constexpr int A1 = 55, A3 = 57, A4 = 58, A5 = 59, A6 = 60;
extern uint32_t fakeUs;
extern int fakeDigital[256], fakeAnalog[256], fakePwm[256], fakePinModes[256];
inline uint32_t millis() { return fakeUs / 1000; }
inline uint32_t micros() { return fakeUs; }
inline void delayMicroseconds(uint32_t n) { fakeUs += n; }
inline void pinMode(int pin, int mode) { fakePinModes[pin] = mode; }
inline void digitalWrite(int p, int v) { fakeDigital[p] = v; }
inline int digitalRead(int p) { return fakeDigital[p]; }
inline int analogRead(int p) { return fakeAnalog[p]; }
inline void analogWrite(int p, int v) { fakePwm[p] = v; }
struct FakeSerial {
  std::deque<char> input;
  std::string output;
  std::string wireOutput, packetBytes;
  uint32_t baud = 0;
  void begin(uint32_t rate) { baud = rate; }
  int available() { return (int)input.size(); }
  int read() {
    int c = (unsigned char)input.front();
    input.pop_front();
    return c;
  }
  int availableForWrite() { return 64; }
  size_t write(uint8_t c) {
    wireOutput += (char)c;
    packetBytes += (char)c;
    if (packetBytes.size() >= 5 && packetBytes.size() == (uint8_t)packetBytes[4] + 7U) {
      output += decodePacket(packetBytes);
      packetBytes.clear();
    }
    return 1;
  }
  void feed(const std::string &s) {
    for (char c : s)
      input.push_back(c);
  }
};
using HardwareSerial = FakeSerial;
extern HardwareSerial Serial, Serial2;
extern uint8_t PCMSK0, PCIFR, PCICR, PINB;
extern uint8_t TCCR5A, TCCR5B, TIMSK5, TIFR5;
extern uint16_t OCR5A, TCNT5;
#define F_CPU 16000000UL
#define _BV(x) (1U << (x))
#define PCINT4 4
#define PCINT5 5
#define PCIF0 0
#define PCIE0 0
#define PB4 4
#define PB5 5
#define CS51 1
#define OCIE5A 1
#define OCF5A 1
