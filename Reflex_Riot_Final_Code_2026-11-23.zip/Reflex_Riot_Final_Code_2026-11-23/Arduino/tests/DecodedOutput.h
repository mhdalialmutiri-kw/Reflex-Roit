#pragma once
#include <string>
#include <stdexcept>
#include <sstream>
#include "../firmware/ReflexRiotMega/BinaryProtocol.h"

// Test adapter exposes decoded lines so the existing sensor regression suite also
// exercises the new packet encoder. wireOutput keeps the actual on-wire bytes.
inline std::string decodePacket(const std::string &wire) {
  const uint8_t *b = (const uint8_t *)wire.data();
  if (wire.size() != (size_t)b[4] + 7 || b[0] != 0xA5 || b[1] != 0x5A || b[2] != 1)
    throw std::runtime_error("Invalid binary header");
  uint16_t crc = 0xFFFF;
  for (size_t i = 2; i < wire.size() - 2; ++i) crc = binary::crcByte(crc, b[i]);
  if (crc != (uint16_t)((b[wire.size()-2] << 8) | b[wire.size()-1]))
    throw std::runtime_error("Invalid binary CRC");
  if (b[3] == 2) return wire.substr(5, b[4]) + "\n";
  const char *actions[] = {"", "TILT_LEFT", "TILT_RIGHT", "TWIST", "SHAKE", "CLAP",
      "HAND_CLOSE", "DIAL_CLOCKWISE", "DIAL_COUNTERCLOCKWISE", "RFID_SCAN", "COVER_LIGHT", "READY"};
  if (b[3] != 1 || b[5] == 0 || b[5] > 11 || b[4] != (b[5] == 9 ? 23 : 13))
    throw std::runtime_error("Invalid binary action");
  auto read32 = [&](size_t offset) {
    uint32_t n = 0;
    for (size_t i = 0; i < 4; ++i) n = (n << 8) | b[offset + i];
    return n;
  };
  std::ostringstream line;
  line << "EVT," << read32(6) << "," << actions[b[5]] << "," << read32(10)
       << "," << read32(14);
  if (b[5] == 9) line << "," << wire.substr(18, 10);
  return line.str() + "\n";
}
