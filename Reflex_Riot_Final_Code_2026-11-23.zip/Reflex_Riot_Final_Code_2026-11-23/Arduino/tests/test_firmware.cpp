#include "Arduino.h"
#include "Wire.h"
#include <iostream>
#include <stdexcept>
uint32_t fakeUs = 0;
int fakeDigital[256], fakeAnalog[256], fakePwm[256], fakePinModes[256];
uint8_t PCMSK0 = 0, PCIFR = 0, PCICR = 0, PINB = _BV(PB5);
uint8_t TCCR5A = 0, TCCR5B = 0, TIMSK5 = 0, TIFR5 = 0;
uint16_t OCR5A = 0, TCNT5 = 0;
HardwareSerial Serial, Serial2;
FakeWire Wire;
#include "../firmware/ReflexRiotMega/ReflexRiotMega.ino"
void PCINT0_vect();
void TIMER5_COMPA_vect();
int checks = 0;
#define CHECK(x)                                                                                   \
  do {                                                                                             \
    ++checks;                                                                                      \
    if (!(x))                                                                                      \
      throw std::runtime_error(std::string("line ") + std::to_string(__LINE__) + ": " + #x);       \
  } while (0)
void run(uint32_t ms) {
  for (uint32_t i = 0; i < ms; ++i) {
    fakeUs += 1000;
    loop();
  }
}
void cmd(const char *s) {
  host.feed(std::string(s) + "\n");
  run(20);
}
void portBit(uint8_t bit, bool high) {
  if (high)
    PINB |= _BV(bit);
  else
    PINB &= ~_BV(bit);
  PCINT0_vect();
}
void rfidByte(uint8_t value, bool validStop = true, bool overlapEcho = false) {
  TCNT5 = (uint16_t)(fakeUs * 2);
  portBit(PB5, false);
  CHECK(TIMSK5 & _BV(OCIE5A));
  CHECK((uint16_t)(OCR5A - TCNT5) == 1250);
  for (uint8_t i = 0; i < 8; ++i) {
    if (overlapEcho && i == 1)
      portBit(PB4, true);
    if (overlapEcho && i == 3)
      portBit(PB4, false);
    portBit(PB5, (value >> i) & 1);
    fakeUs += 417;
    TCNT5 = OCR5A;
    TIMER5_COMPA_vect();
    CHECK((uint16_t)(OCR5A - TCNT5) == 833);
  }
  portBit(PB5, validStop);
  fakeUs += 834;
  TIMER5_COMPA_vect();
  CHECK(!(TIMSK5 & _BV(OCIE5A)));
  if (!validStop)
    portBit(PB5, true);
}
void rfidText(const std::string &tagFrame) {
  for (uint8_t c : tagFrame)
    rfidByte(c);
}
int occurrences(const std::string &s, const std::string &needle) {
  int n = 0;
  size_t at = 0;
  while ((at = s.find(needle, at)) != std::string::npos) {
    ++n;
    at += needle.size();
  }
  return n;
}
void coreTests() {
  CHECK(rr::elapsed(10, UINT32_MAX - 9) == 20);
  rr::Debouncer b;
  b.reset(false, 0);
  CHECK(!b.update(true, 1));
  CHECK(!b.update(false, 5));
  CHECK(!b.update(true, 10));
  CHECK(!b.update(true, 34));
  CHECK(b.update(true, 35));
  CHECK(b.stable);
  CHECK(!b.update(true, 90));
  rr::Gate g;
  CHECK(!g.update(true, false, 0, 100, 20));
  CHECK(!g.update(true, false, 500, 100, 20));
  CHECK(!g.update(false, true, 510, 100, 20));
  CHECK(!g.update(false, true, 610, 100, 20));
  CHECK(!g.update(true, false, 620, 100, 20));
  CHECK(g.update(true, false, 640, 100, 20));
  CHECK(!g.update(true, false, 900, 100, 20));
  g.reset();
  CHECK(!g.update(true, false, 1000, 100, 20));
  rr::Encoder e;
  e.reset(3);
  CHECK(e.update(1) == rr::NONE);
  CHECK(e.update(0) == rr::DIAL_CLOCKWISE);
  CHECK(e.update(2) == rr::NONE);
  CHECK(e.update(3) == rr::DIAL_CLOCKWISE);
  CHECK(e.update(2) == rr::NONE);
  CHECK(e.update(0) == rr::DIAL_COUNTERCLOCKWISE);
  CHECK(e.update(1) == rr::NONE);
  CHECK(e.update(3) == rr::DIAL_COUNTERCLOCKWISE);
  e.reset(0);
  CHECK(e.update(3) == rr::NONE);
  CHECK(e.total == 0);
  rr::RfidFrame r;
  bool complete = false;
  uint32_t now = 0;
  for (char c : std::string("noise\n012345abcd\r"))
    complete = r.feed(c, now++);
  CHECK(complete);
  CHECK(std::string(r.tag) == "012345ABCD");
  complete = false;
  for (char c : std::string("\n012345ABCDX\r"))
    complete |= r.feed(c, now++);
  CHECK(!complete);
  r.feed('\n', 0);
  CHECK(!r.feed('A', 200));
  CHECK(!r.receiving);
  rr::CardLatch latch;
  CHECK(latch.observe("012345ABCD", 0));
  CHECK(!latch.observe("012345ABCD", 100));
  CHECK(!latch.observe("012345ABCD", 900));
  CHECK(latch.observe("012345ABCD", 1900));
  CHECK(latch.observe("112345ABCD", 1910));
  int base[3] = {500, 500, 700};
  float gyroV[3] = {0, 0, 0};
  for (int axis = 0; axis < 3; ++axis) {
    for (int sign : {-1, 1}) {
      rr::Motion motion;
      motion.reset(0);
      float rates[3] = {0, 0, 0};
      rates[axis] = sign * 60.0f;
      // Rotating without D40 never counts.
      for (uint32_t t = 10; t <= 400; t += 10)
        CHECK(motion.update(rates, false, t) == rr::NONE);
      int events = 0;
      for (uint32_t t = 410; t <= 1000; t += 10) {
        auto action = motion.update(rates, true, t);
        if (action != rr::NONE) { CHECK(action == rr::TWIST); ++events; }
      }
      CHECK(events == 1);
      // Continuing, reversing, pausing, or returning cannot double-score this hold.
      rates[axis] = -sign * 90.0f;
      for (uint32_t t = 1010; t <= 1600; t += 10)
        CHECK(motion.update(rates, true, t) == rr::NONE);
      CHECK(motion.update(rates, false, 1610) == rr::NONE);
      events = 0;
      for (uint32_t t = 1620; t <= 2100; t += 10) {
        auto action = motion.update(rates, true, t);
        if (action != rr::NONE) { CHECK(action == rr::TWIST); ++events; }
      }
      CHECK(events == 1);
    }
  }
  rr::Motion noise;
  noise.reset(0);
  float small[3] = {5, -8, 4};
  for (uint32_t t = 10; t <= 3000; t += 10)
    CHECK(noise.update(small, true, t) == rr::NONE);
  float diagonal[3] = {30, 30, 30};
  noise.reset(0);
  int events = 0;
  for (uint32_t t = 10; t <= 600; t += 10) {
    auto action = noise.update(diagonal, true, t);
    if (action != rr::NONE) { CHECK(action == rr::TWIST); ++events; }
  }
  CHECK(events == 1); // Mounting diagonally does not require axis remapping.
  noise.reset(0);
  float impulse[3] = {100, 0, 0};
  CHECK(noise.update(impulse, true, 10) == rr::NONE);
  CHECK(noise.update(impulse, true, 200) == rr::NONE); // A time gap cannot score.
  CHECK(!noise.latched);
  rr::Calibration cal;
  for (int i = 0; i < 250; ++i)
    cal.add(base, gyroV, 600);
  CHECK(cal.stationary());
  cal.high[0] += 100;
  CHECK(!cal.stationary());
}
void firmwareTests() {
  std::fill(fakeDigital, fakeDigital + 256, HIGH);
  std::fill(fakeAnalog, fakeAnalog + 256, 500);
  fakeAnalog[A3] = 600;
  Wire.rawGyro[0] = -214; // Similar stationary offset to the tested board.
  setup();
  Wire.fail = true;
  run(500);
  CHECK(mpuOk && calibrating); // Sampling must wait until the MPU has settled.
  Wire.fail = false;
  run(4000);
  CHECK(mpuOk && calibrated && !armed && !bench && !fault);
  CHECK(Wire.registers[0x1B] == 8);
  CHECK(Wire.registers[0x1C] == 0);
  CHECK(host.baud == (RR_USE_XBEE ? 9600UL : 115200UL));
  CHECK((RR_USE_XBEE ? Serial : Serial2).output.empty());
  CHECK(host.output.find(RR_USE_XBEE ? "BOOT,REFLEX_RIOT,1.3,XBEE,9600"
                                  : "BOOT,REFLEX_RIOT,1.3,USB,115200") != std::string::npos);
  CHECK(baseline[2] == 576 && fabsf(gyro[0]) < 0.01f);
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT);
  CHECK(host.output.find("STATUS,CALIBRATED") != std::string::npos);
  CHECK(Wire.registers[0x6B] == 1 && Wire.registers[0x1A] == 3 && Wire.registers[0x19] == 9);
  cmd("CMD,1,TEST_ON");
  CHECK(bench);
  cmd("CMD,2,INPUT_ARM,1");
  CHECK(!armed);
  CHECK(host.output.find("ERR,2,TEST_MODE") != std::string::npos);
  int readyBefore = occurrences(host.output, ",READY,");
  fakeDigital[4] = LOW;
  run(40);
  CHECK(occurrences(host.output, ",READY,") == readyBefore);
  fakeDigital[4] = HIGH;
  fakeDigital[50] = LOW;
  run(40);
  CHECK(occurrences(host.output, ",READY,") == readyBefore + 1);
  run(100);
  CHECK(occurrences(host.output, ",READY,") == readyBefore + 1);
  fakeDigital[50] = HIGH;
  run(40);
  cmd("CMD,3,TEST_OFF");
  cmd("CMD,4,INPUT_ARM,1");
  CHECK(armed && epoch == 1);
  cmd("CMD,4,INPUT_ARM,1");
  CHECK(armed); // Idempotent replay, no reset.
  cmd("CMD,4,LED_GREEN");
  CHECK(host.output.find("ERR,4,ID_REUSED") != std::string::npos);
  cmd("CMD,5,INPUT_DISARM");
  CHECK(!armed);
  cmd("CMD,6,INPUT_ARM,1");
  CHECK(!armed);
  cmd("CMD,7,INPUT_ARM,2");
  CHECK(armed);
  run(3600);
  CHECK(!armed);
  CHECK(host.output.find("HOST_TIMEOUT_DISARMED") != std::string::npos);
  cmd("CMD,7,INPUT_ARM,2");
  CHECK(!armed); // A replay after timeout must NOT restart gameplay.
  cmd("CMD,8,INPUT_ARM,3");
  CHECK(armed);
  // Near hand held at arm cannot score: require far samples first.
  int n = occurrences(host.output, ",HAND_CLOSE,");
  updateDistance(80, millis());
  updateDistance(80, millis() + 100);
  run(10);
  CHECK(occurrences(host.output, ",HAND_CLOSE,") == n);
  uint32_t at = millis();
  updateDistance(600, at);
  updateDistance(600, at + 201);
  updateDistance(80, at + 220);
  updateDistance(80, at + 290);
  run(10);
  CHECK(occurrences(host.output, ",HAND_CLOSE,") == n + 1);
  updateDistance(80, at + 500);
  run(10);
  CHECK(occurrences(host.output, ",HAND_CLOSE,") == n + 1);
  cmd("CMD,9,INPUT_DISARM");
  n = occurrences(host.output, ",RFID_SCAN,");
  rfidText("\n012345ABCD\r");
  run(50);
  CHECK(occurrences(host.output, ",RFID_SCAN,") == n);
  cmd("CMD,10,INPUT_ARM,4");
  rfidText("\n012345ABCD\r");
  run(50);
  CHECK(occurrences(host.output, ",RFID_SCAN,") == n);
  run(1100);
  rfidText("\n012345ABCD\r");
  run(50);
  CHECK(occurrences(host.output, ",RFID_SCAN,") == n + 1);
  cmd("CMD,11,TELEMETRY,ON");
  run(300);
  CHECK(host.output.find("RAW,ACCEL_COUNTS") != std::string::npos);
  host.feed(std::string(90, 'X') + "\n");
  run(50);
  CHECK(host.output.find("RX_OVERSIZE_OR_TIMEOUT") != std::string::npos);
  cmd("CMD,4294967296,INPUT_DISARM");
  CHECK(armed); // Overflowed command ID rejected.
  cmd("CMD,12,INPUT_DISARM");
  CHECK(!armed);
  Wire.shortReads = 2;
  run(20);
  CHECK(mpuOk && calibrated && Wire.shortReads == 0);
  Wire.fail = true;
  run(20);
  CHECK(!mpuOk && !calibrated && !armed);
  CHECK(host.output.find("RAW,MPU_I2C,TX_CODE,4,RX_BYTES,0,TIMEOUT,0") != std::string::npos);
  cmd("CMD,13,INPUT_ARM,5");
  CHECK(!armed);
  Wire.fail = false;
  cmd("CMD,14,CALIBRATE");
  run(4000);
  CHECK(calibrated);
  cmd("CMD,15,INPUT_ARM,5");
  CHECK(armed);
  for (int i = 0; i < 12; ++i)
    line("STATUS,FILL");
  CHECK(fault && !armed);
  run(100);
  CHECK(host.output.find("TX_OVERFLOW_EVENTS_INVALID") != std::string::npos);
  fakeAnalog[A3] = 69; // Measured uncovered light on the assembled station.
  cmd("CMD,16,CALIBRATE");
  run(4000);
  CHECK(calibrated && !fault && lightBaseline == 69);
  // Emitted sensor frames cover every non-motion action, without expected-action filtering.
  cmd("CMD,17,TEST_ON");
  run(300);
  n = occurrences(host.output, ",DIAL_CLOCKWISE,");
  fakeDigital[cfg::ENC_CLK] = LOW; // 11 → 01 → 00, one detent.
  run(10);
  fakeDigital[cfg::ENC_DT] = LOW;
  run(10);
  CHECK(occurrences(host.output, ",DIAL_CLOCKWISE,") == n + 1);
  n = occurrences(host.output, ",DIAL_COUNTERCLOCKWISE,");
  fakeDigital[cfg::ENC_DT] = HIGH; // 00 → 01 → 11, one detent back.
  run(10);
  fakeDigital[cfg::ENC_CLK] = HIGH;
  run(10);
  CHECK(occurrences(host.output, ",DIAL_COUNTERCLOCKWISE,") == n + 1);
  n = occurrences(host.output, ",TWIST,");
  CHECK(cfg::TRIGGER == 40);
  fakeDigital[22] = fakeDigital[30] = LOW; // Old trigger pins must be ignored.
  Wire.rawGyro[1] = 3930;
  run(500);
  CHECK(occurrences(host.output, ",TWIST,") == n);
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT);
  fakeDigital[22] = fakeDigital[30] = HIGH;
  fakeDigital[cfg::TRIGGER] = LOW;
  run(500);
  CHECK(occurrences(host.output, ",TWIST,") == n + 1);
  Wire.rawGyro[1] = -3930;
  run(600);
  CHECK(occurrences(host.output, ",TWIST,") == n + 1); // Return rotation does not count twice.
  fakeDigital[cfg::TRIGGER] = HIGH;
  run(50);
  fakeDigital[cfg::TRIGGER] = LOW;
  run(500);
  CHECK(occurrences(host.output, ",TWIST,") == n + 2);
  Wire.rawGyro[1] = 0;
  Wire.rawAccel[0] = -4608;
  run(500);
  Wire.rawAccel[0] = 4608;
  run(500);
  CHECK(occurrences(host.output, ",TILT_LEFT,") == 0);
  CHECK(occurrences(host.output, ",TILT_RIGHT,") == 0);
  CHECK(occurrences(host.output, ",SHAKE,") == 0);
  Wire.rawAccel[0] = 0;
  fakeDigital[cfg::TRIGGER] = HIGH;
  n = occurrences(host.output, ",COVER_LIGHT,");
  fakeAnalog[A3] = 52;
  run(150);
  CHECK(occurrences(host.output, ",COVER_LIGHT,") == n + 1);
  run(300);
  CHECK(occurrences(host.output, ",COVER_LIGHT,") == n + 1);
  fakeAnalog[A3] = 69;
  run(300);
  n = occurrences(host.output, ",CLAP,");
  fakeAnalog[A1] = 800;
  run(1);
  fakeAnalog[A1] = 500;
  run(30);
  CHECK(occurrences(host.output, ",CLAP,") == n + 1);
  // Echo ISR captures width even if main loop is doing another task.
  pulseInputs::clearEcho();
  rfidByte(0xA5, true, true);
  uint32_t echoWidth;
  CHECK(pulseInputs::takeEcho(echoWidth) && echoWidth == 834);
  CHECK(pulseInputs::readRfidByte() == 0xA5);
  CHECK(pulseInputs::readRfidByte() < 0);
  fakeUs += (32500UL - fakeUs % 32768UL + 32768UL) % 32768UL;
  rfidByte(0x00); // First compare crosses the 16-bit timer wrap.
  CHECK(pulseInputs::readRfidByte() == 0x00);
  cmd("CMD,18,TEST_OFF");
  CHECK(!armed && !bench);
  cmd("CMD,19,TEST_ON");
  run(200);
  n = occurrences(host.output, ",CLAP,");
  cmd("CMD,20,MUTE_CLAP,500");
  fakeAnalog[A1] = 800;
  run(1);
  fakeAnalog[A1] = 500;
  run(50);
  CHECK(occurrences(host.output, ",CLAP,") == n);
  run(650);
  fakeAnalog[A1] = 800;
  run(1);
  fakeAnalog[A1] = 500;
  run(30);
  CHECK(occurrences(host.output, ",CLAP,") == n + 1);
  cmd("CMD,21,TEST_OFF");
  CHECK(!bench);
  host.feed("CMD,22,INPUT_");
  run(600);
  host.feed("ARM,6\n");
  run(20);
  CHECK(!armed);
  cmd("CMD,23,INPUT_ARM,6");
  CHECK(armed);
  cmd("CMD,24,INPUT_DISARM");
  CHECK(!armed);
  cmd("CMD,25,INPUT_ARM,7");
  CHECK(armed);
  cmd("CMD,26,FEEDBACK_WRONG");
  CHECK(!armed && fakeDigital[23] == LOW && fakePinModes[23] == INPUT && fakePwm[cfg::RED] == 100);
  run(140);
  cmd("CMD,26,FEEDBACK_WRONG");
  run(100);
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT); // Retried command cannot enable motor output.
  cmd("CMD,26,FEEDBACK_WRONG");
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT); // Every wrong-move command leaves the motor disconnected.
  cmd("CMD,27,FEEDBACK_WRONG");
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT);
  cmd("CMD,28,INPUT_DISARM");
  CHECK(fakeDigital[23] == LOW && fakePinModes[23] == INPUT);
  cmd("CMD,29,INPUT_ARM,8");
  rfidByte('x', false);
  run(20);
  CHECK(!armed && fault && host.output.find("ERR,0,RFID_STREAM_ERROR") != std::string::npos);
  CHECK(pulseInputs::readRfidByte() < 0);
  for (int i = 0; i < 32; ++i)
    rfidByte('x');
  CHECK(pulseInputs::takeRfidError());
  CHECK(pulseInputs::readRfidByte() < 0);
  Wire.rawAccel[2] = 0; // A stationary zero vector cannot pass calibration.
  cmd("CMD,30,CALIBRATE");
  run(4000);
  CHECK(!calibrated && host.output.find("CALIBRATION_FAILED_CHECK_RAW") != std::string::npos);
  Wire.rawAccel[2] = 16384;
  fakeAnalog[A3] = 31;
  cmd("CMD,31,CALIBRATE");
  run(4000);
  CHECK(calibrated && lightBaseline == 31);
  cmd("CMD,32,TEST_ON");
  run(300);
  n = occurrences(host.output, ",COVER_LIGHT,");
  fakeAnalog[A3] = 27;
  run(200);
  CHECK(occurrences(host.output, ",COVER_LIGHT,") == n);
  fakeAnalog[A3] = 10;
  run(200);
  CHECK(occurrences(host.output, ",COVER_LIGHT,") == n + 1);
  cmd("CMD,33,TEST_OFF");
  cmd("CMD,34,CALIBRATE");
  run(4000);
  CHECK(!calibrated && host.output.find("LIGHT,10,MIC_PEAK,") != std::string::npos);
  Wire.who = 0;
  CHECK(!mpu.begin());
  Wire.who = 0x68;
  CHECK(mpu.begin());
  Wire.rawGyro[0] = -6550;
  Wire.rawAccel[0] = -16384;
  int convertedAccel[3];
  float converted[3];
  CHECK(mpu.readSample(convertedAccel, converted));
  CHECK(convertedAccel[0] == 448 && convertedAccel[2] == 576);
  CHECK(fabsf(converted[0] + 100) < .01f);
}
int main() {
  try {
    coreTests();
    firmwareTests();
    std::cout << "PASS " << checks
              << " assertions (" << HOST_NAME << ") against the firmware with simulated I/O.\n";
    return 0;
  } catch (const std::exception &e) {
    std::cerr << "FAIL " << e.what() << "\n";
    return 1;
  }
}
